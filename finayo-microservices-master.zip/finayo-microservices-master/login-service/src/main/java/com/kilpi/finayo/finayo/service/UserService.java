package com.kilpi.finayo.finayo.service;

import com.kilpi.finayo.finayo.Exceptions.UserAlreadyExistException;
import com.kilpi.finayo.finayo.VO.UserVO;
import com.kilpi.finayo.finayo.entity.UserEntity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;


public interface UserService {
    public UserDetails loadUserByEmail(String email);

    UserVO create(UserVO user);

    boolean checkIfUserExist(String userName);

    UserEntity findUserByEmail(String email);

    UserEntity findUserByUid(String code);
}
