package com.kilpi.finayo.finayo.controller;

import com.kilpi.finayo.finayo.VO.UserVO;
import com.kilpi.finayo.finayo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping(value = "register")
    public UserVO create(@RequestBody UserVO user){
        return userService.create(user);

    }
}
