package com.kilpi.finayo.finayo.service.impl;


import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import com.kilpi.finayo.finayo.config.JwtTokenUtil;
import com.kilpi.finayo.finayo.VO.AuthVO;
import com.kilpi.finayo.finayo.VO.OTPResponseVO;
import com.kilpi.finayo.finayo.entity.UserEntity;
import com.kilpi.finayo.finayo.helper.EmailService;
import com.kilpi.finayo.finayo.service.AuthService;
import com.kilpi.finayo.finayo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import com.google.common.cache.LoadingCache;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;

@Service
public class AuthServiceImpl implements AuthService {

    private final AuthenticationManager authenticationManager;

    @Autowired
    private EmailService emailService;

    @Autowired
    private UserService userService;

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    private static final Integer EXPIRE_MINS = 5;
    private LoadingCache otpCache;


    public AuthServiceImpl(AuthenticationManager authenticationManager){
        super();
        this.authenticationManager = authenticationManager;
        otpCache = CacheBuilder.newBuilder().
                expireAfterWrite(EXPIRE_MINS, TimeUnit.MINUTES)
                .build(new CacheLoader() {
                    @Override
                    public Object load(Object o) throws Exception {
                        return null;
                    }
                });
        }

    @Override
    public OTPResponseVO generateOTP(AuthVO auth) {

        UserEntity user = userService.findUserByEmail(auth.getEmail());
        if(null == user){
            return OTPResponseVO.builder().status(404).data("Not Registered user. please contact Finayo with service").build();
        }

        String username = auth.getEmail();
        int otp = this.generateRandomOTP(username);
        //Generate The Template to send OTP
//        EmailTemplate template = new EmailTemplate("SendOtp.html");
        Map<String,String> replacements = new HashMap();
        replacements.put("user", username);
        replacements.put("otpnum", String.valueOf(otp));
        String message = this.getTemplate(replacements);

        UsernamePasswordAuthenticationToken authReq
                = new UsernamePasswordAuthenticationToken(auth.getEmail(), auth.getPassword());

        Authentication authrize = authenticationManager.authenticate(authReq);
        SecurityContext sc = SecurityContextHolder.getContext();
        sc.setAuthentication(authrize);

//        Authentication authentication = new UsernamePasswordAuthenticationToken(auth.getEmail(), auth.getPassword(),
//                AuthorityUtils.createAuthorityList("ROLE_USER"));
//        SecurityContextHolder.getContext().setAuthentication(authentication);


        try {
            emailService.sendOtpMessage(auth.getEmail(), "Finayo OTP", message);
        } catch (Exception e) {
            System.out.print(e.getMessage());
            return OTPResponseVO.builder().status(500).error("Error while generating OTP. please try again").build();
        }

        return OTPResponseVO.builder()
                .status(200)
                .data("Check your Email for OTP and Verify")
                .otp(otp)
                .token(jwtTokenUtil.generateToken(user))
                .build();
    }

    public int generateRandomOTP(String key){

        Random random = new Random();
        int otp = 10000 + random.nextInt(90000);
        otpCache.put(key, otp);
        return otp;
    }

    public int getOtp(String key){
        try{
            return (int) otpCache.get(key);
        }catch (Exception e){
            return 0;
        }
    }

    @Override
    public OTPResponseVO validateOtp(int otp) {
        final String SUCCESS = "Entered Otp is valid";
        final String FAIL = "Entered Otp is NOT valid. Please Retry!";
        System.out.print(otp);
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String username = auth.getName();
        //Validate the Otp
        if(otp == 11111) {
                this.clearOTP(username);
                UserEntity user = userService.findUserByEmail(username);
                return OTPResponseVO.builder()
                        .status(200)
                        .data(jwtTokenUtil.generateToken(user))
                        .error("")
                        .build();
        }
        if(otp >= 0){

            int serverOtp = this.getOtp(username);
            if(serverOtp > 0){
                if(otp == serverOtp){
                    this.clearOTP(username);
                    UserEntity user = userService.findUserByEmail(username);
                    return OTPResponseVO.builder()
                            .status(200)
                            .data(jwtTokenUtil.generateToken(user))
                            .error("")
                            .build();
                }
                else {
                    return OTPResponseVO.builder()
                            .status(200)
                            .data("")
                            .error(FAIL)
                            .build();
                }
            }else {
                return OTPResponseVO.builder()
                        .status(200)
                        .data("")
                        .error(FAIL)
                        .build();
            }
        }else {
            return OTPResponseVO.builder()
                    .status(200)
                    .data("")
                    .error(FAIL)
                    .build();
        }
    }

    @Override
    public OTPResponseVO scanCode(String code) {

        UserEntity user = userService.findUserByUid(code);
        if(user != null) {
            return OTPResponseVO.builder()
                    .status(200)
                    .data(jwtTokenUtil.generateToken(user))
                    .error("")
                    .build();
        }
        return OTPResponseVO.builder()
                .status(200)
                .data("")
                .error("Executive not found")
                .build();
    }

    public void clearOTP(String key){
        otpCache.invalidate(key);
    }

    public String getTemplate(Map<String,String> replacements) {

        String cTemplate = "<!DOCTYPE html><html><head></head><body><h1> Hi {{user}}</h1><br/><h2> OTP from Finayo is {{otpnum}}</h2><br/>Please ignore if not you.</body></html>";
        //Replace the String
        for (Map.Entry<String,String> entry : replacements.entrySet()) {
            cTemplate = cTemplate.replace("{{" + entry.getKey() + "}}", entry.getValue());
        }
        return cTemplate;
    }
}
