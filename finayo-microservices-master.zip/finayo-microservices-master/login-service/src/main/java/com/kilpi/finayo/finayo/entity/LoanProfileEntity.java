package com.kilpi.finayo.finayo.entity;

import javax.persistence.*;

public class LoanProfileEntity {


    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Integer id;

    @OneToOne
    private LoanEntity loan;

    @OneToMany
    private UserEntity user;

    @Column(name = "businessType")
    private String businessType;

    @Column(name = "loanRequirement")
    private String loanRequirement;

    @Column(name = "PanCard")
    private String PanCard;

    @Column(name = "downPayment")
    private String downPayment;

    @Column(name = "applicationType")
    private String applicationType;

    @Column(name = "SalaryMonthly")
    private String SalaryMonthly;

    @Column(name = "TypeOrgnization")
    private String TypeOrgnization;

    @Column(name = "companyName")
    private String companyName;

    @Column(name = "grossIncome")
    private String grossIncome;

}
