package com.kilpi.finayo.finayo.service.impl;

import com.kilpi.finayo.finayo.Exceptions.UserAlreadyExistException;
import com.kilpi.finayo.finayo.VO.UserVO;
import com.kilpi.finayo.finayo.entity.DSAEntity;
import com.kilpi.finayo.finayo.entity.UserEntity;
import com.kilpi.finayo.finayo.repository.DSAEntityRepository;
import com.kilpi.finayo.finayo.repository.UserRepository;
import com.kilpi.finayo.finayo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private DSAEntityRepository dsaEntityRepository;

    @Override
    public UserDetails loadUserByEmail(String email)  throws UsernameNotFoundException {

            Optional<UserEntity> users = userRepository.findByUsername(email);
//            GrantedAuthority authority = new SimpleGrantedAuthority(users.getRole());
            UserDetails userDetails = (UserDetails) new User(users.get().getUsername(),
                    users.get().getPassword(),null);

            return userDetails;
    }

    @Override
    public UserVO create(UserVO user) {


        //Let's check if user already registered with us
        if(checkIfUserExist(user.getEmail())){
            throw new UserAlreadyExistException("User already exists for this email");
        }

        DSAEntity company = this.getCompany(user);

        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

        UserEntity newUser = new UserEntity();
        newUser.setFirstName(user.getFname());
        newUser.setLastName(user.getLname());
        newUser.setUsername(user.getEmail());
        newUser.setPassword(passwordEncoder.encode(user.getPassword()));
        newUser.setCity(user.getCity());
        newUser.setAddress(user.getAddress());
        newUser.setMobile(user.getMobile());
        newUser.setRole(user.getRole());
        newUser.setCompany(company);
        newUser.setRole(user.getRole());
        newUser.setActive(Boolean.TRUE);
        newUser = userRepository.save(newUser);

        String uid = newUser.getCity().substring(0,2).toUpperCase();
        uid += newUser.getMobile().substring(newUser.getMobile().length() - 4);
        uid += newUser.getFirstName().substring(0,1).toUpperCase();
        uid += newUser.getLastName().substring(0,1).toUpperCase();
        uid += String.format("%02d",newUser.getId());

        newUser.setUniqueId(uid);

        return userRepository.save(newUser).toVo();
    }

    private DSAEntity getCompany(UserVO user) {
        String companyUniqueName = user.getCompany().replace(" ","").toUpperCase();

        DSAEntity company = dsaEntityRepository.findFirstByUniqueName(companyUniqueName);

        if(company == null){
            company = new DSAEntity();
            company.setName(user.getCompany());
            company.setCategory(user.getBtype());
            company.setUniqueName(companyUniqueName);
            company = dsaEntityRepository.save(company);
        }
        return company;
    }

    @Override
    public boolean checkIfUserExist(String email) {
        Optional<UserEntity> user = userRepository.findByUsername(email);
        return  user.isPresent() ? true : false;
    }

    @Override
    public UserEntity findUserByEmail(String email) {
        return userRepository.findByUsername(email).get();
    }

    @Override
    public UserEntity findUserByUid(String code) {
        return userRepository.findByUniqueId(code);
    }

}
