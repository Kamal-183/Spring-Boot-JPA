package com.kilpi.finayo.finayo.Exceptions;

import lombok.Getter;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.IM_USED)
public class UserAlreadyExistException extends RuntimeException {

    @Getter
    private final String errMsg;

    @Getter
    private final String[] args;

    public UserAlreadyExistException(String errMsg){
        this(errMsg, new String[0]);
    }

    public UserAlreadyExistException(String errMsg, String... args){
        super(errMsg);
        this.errMsg = errMsg;
        this.args = args.clone();
    }

}
