package com.kilpi.finayo.finayo.entity;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

public class LoanEntity {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "loan_id")
    private String loanId;

    @Column(name = "agent_id")
    private String agent;

    @Column(name = "dsa_id")
    private DSAEntity dsa;

    @Column(name = "status")
    private String status;

}
