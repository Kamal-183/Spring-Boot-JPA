package com.kilpi.finayo.finayo.VO;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class OTPResponseVO {
    public Integer status;
    public String data;
    public String token;
    public Integer otp;
    public String error;
}
