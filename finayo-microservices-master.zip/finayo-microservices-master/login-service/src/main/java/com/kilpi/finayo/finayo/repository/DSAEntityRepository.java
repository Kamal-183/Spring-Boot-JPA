package com.kilpi.finayo.finayo.repository;

import com.kilpi.finayo.finayo.entity.DSAEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DSAEntityRepository extends JpaRepository<DSAEntity, Integer> {
    DSAEntity findFirstByUniqueName(String companyUniqueName);
}