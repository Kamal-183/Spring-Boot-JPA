package com.kilpi.finayo.finayo.VO;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class AuthVO {
    String email;
    String password;
}
