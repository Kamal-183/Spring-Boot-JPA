package com.kilpi.finayo.finayo.service;


import com.kilpi.finayo.finayo.VO.AuthVO;
import com.kilpi.finayo.finayo.VO.OTPResponseVO;

import javax.mail.MessagingException;

public interface AuthService {
    OTPResponseVO generateOTP(AuthVO auth);

    void clearOTP(String username);

    int getOtp(String username);

    OTPResponseVO validateOtp(int otp);

    OTPResponseVO scanCode(String code);
}
