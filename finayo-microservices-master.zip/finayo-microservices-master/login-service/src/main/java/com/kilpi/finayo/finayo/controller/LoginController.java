package com.kilpi.finayo.finayo.controller;

import com.kilpi.finayo.finayo.VO.AuthVO;
import com.kilpi.finayo.finayo.VO.OTPResponseVO;
import com.kilpi.finayo.finayo.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/login")
public class LoginController {

    @Autowired
    private AuthService authService;


    @RequestMapping(method = RequestMethod.POST)
    public OTPResponseVO generateOTP(@RequestBody AuthVO auth){
        return authService.generateOTP(auth);
    }

    @GetMapping(value ="/validate")
    public OTPResponseVO validateOtp(@RequestParam("otp") int otp){
        return authService.validateOtp(otp);
    }

    @GetMapping(value ="/scan/{code}")
    public OTPResponseVO scanCode(@PathVariable String code){
        return authService.scanCode(code);
    }
}
