package com.kilpi.finayo.finayo.entity;

import javax.persistence.*;

public class VehicalEntity {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Integer id;


    @Column(name = "vehicle_name")
    private String vehicleName;

    @Column(name = "ex_showroom")
    private String exShowroom;

    @Column(name = "road_price")
    private String roadPrice;

    @Column(name = "rider_name")
    private String riderName;

    @Column(name = "dob")
    private String birthData;

    @Column(name = "father_name")
    private String fatherName;
}
