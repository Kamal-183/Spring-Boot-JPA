package com.kilpi.finayo.client;


public class ClientService {
}
