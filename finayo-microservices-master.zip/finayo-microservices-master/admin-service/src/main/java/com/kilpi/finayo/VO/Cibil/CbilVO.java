package com.kilpi.finayo.VO.Cibil;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CbilVO {
    private String  InquiryPurpose;
    private String FirstName;
    private String MiddleName;
    private String LastName;
    private String DOB;
    private List<InquiryAddressesVO> InquiryAddresses;
    private List<InquiryPhonesVO> InquiryPhones;
    private List<IDDetailsVO> IDDetails;
    private MFIDetailsVO MFIDetails;
    private List<ScoreVO> Score;
}
