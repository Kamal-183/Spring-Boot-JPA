package com.kilpi.finayo.Service.impl;

import com.kilpi.finayo.Config.AppProperties;
import com.kilpi.finayo.Domain.BankEntity;
import com.kilpi.finayo.Domain.BranchEntity;
import com.kilpi.finayo.Domain.ExecutiveEntity;
import com.kilpi.finayo.Domain.UserEntity;
import com.kilpi.finayo.Repository.BankRepository;
import com.kilpi.finayo.Repository.BranchRepository;
import com.kilpi.finayo.Repository.ExecutiveRepository;
import com.kilpi.finayo.Repository.UserRepository;
import com.kilpi.finayo.Service.BankService;
import com.kilpi.finayo.Service.ExecutiveService;
import com.kilpi.finayo.VO.BankVO;
import com.kilpi.finayo.VO.ExecutiveVO;
import com.kilpi.finayo.exception.NotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class BankServiceImpl implements BankService {

    @Autowired
    private BankRepository bankRepository;

    @Autowired
    private BranchRepository branchRepository;

    @Autowired
    private UserRepository userRepository;

    @Override
    public List<BankVO> load() {
        return bankRepository.findAll().stream().map(BankEntity::toVo).collect(Collectors.toList());
    }

    @Override
    public BankVO create(BankVO bankVO) {

        BankEntity entity = new BankEntity();
        entity.setBankname(bankVO.getBankName());
        entity.setIfscCode(bankVO.getIfsc());
        entity.setInterestRate(bankVO.getInterestRate());
        entity.setAcptCibil(bankVO.getCibil());
        entity.setEmail(bankVO.getEmail());
        entity.setMobile(bankVO.getMobile());
        entity.setActive(Boolean.TRUE);
        entity.setAddress(bankVO.getAddress());
        entity.setCity(bankVO.getCity());
        entity = bankRepository.save(entity);

        String code = bankVO.getBankName().substring(0,2).toUpperCase();
        code +=  bankVO.getIfsc().substring(0,2).toUpperCase();
        code += String.format("%04d", entity.getId());
        entity.setCode(code);

        this.createUser(entity);

        return bankRepository.save(entity).toVo();
    }

    @Override
    public BankVO view(Integer id) {
        Optional<BankEntity> isBank = bankRepository.findById(id);
        if(isBank.isPresent()) {
            return isBank.get().toVo();
        }
        return null;
    }

    @Override
    public BankVO update(Integer id, BankVO bankVO) {

        Optional<BankEntity> isBank = bankRepository.findById(id);
        if(isBank.isPresent()){
            BankEntity entity = isBank.get();
            entity.setBankname(bankVO.getBankName());
            entity.setEmail(bankVO.getEmail());
            entity.setMobile(bankVO.getMobile());
            entity.setActive(Boolean.TRUE);
            entity.setAddress(bankVO.getAddress());
            entity.setCity(bankVO.getCity());

            return bankRepository.save(entity).toVo();
        }
        return null;
    }

    @Override
    public List<BankVO> getBanksByCibil(Double score) {
        return bankRepository.findByMinCibil(score).stream().map(BankEntity::toVo).collect(Collectors.toList());

    }

    private void createUser(BankEntity entity) {


        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

        UserEntity newUser = new UserEntity();
        newUser.setFirstName(entity.getBankname());
        newUser.setLastName(" ");
        newUser.setUsername(entity.getEmail());
        newUser.setPassword(passwordEncoder.encode(entity.getCode()));
        newUser.setCity(entity.getCity());
        newUser.setAddress(entity.getAddress());
        newUser.setMobile(entity.getMobile());
        newUser.setRole("LENDER");
        newUser.setCompany(null);
        newUser.setActive(Boolean.TRUE);
        newUser.setUniqueId(entity.getCode());
        
         userRepository.save(newUser);
    }
}
