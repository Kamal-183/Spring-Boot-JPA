package com.kilpi.finayo.Service;

import com.kilpi.finayo.VO.BranchVO;
import com.kilpi.finayo.VO.OptionsVO;

import java.util.List;

public interface BusinessService {

    List<OptionsVO> load();

    OptionsVO create(OptionsVO optionsVO);

}
