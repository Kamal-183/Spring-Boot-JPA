package com.kilpi.finayo.Controller;

import com.kilpi.finayo.Service.ExecutiveService;
import com.kilpi.finayo.VO.ExecutiveVO;
import com.kilpi.finayo.VO.OrgVO;
import com.kilpi.finayo.VO.ResponseVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import javax.validation.Valid;

@RestController
@RequestMapping("executive")
public class ExecutiveController {

    @Autowired
    private ExecutiveService ExecutiveService;

    @GetMapping(value = "/list")
    public ResponseVO load(@PathVariable(name = "limit", required = false) Integer limit) {
        return ResponseVO.builder()
                .data(ExecutiveService.load(limit))
                .status(200)
                .message("List Of Executives")
                .build();
    }

    @PostMapping(value = "/create")
    public ResponseVO create(@Valid @RequestBody ExecutiveVO ExecutiveVO) {
        return ResponseVO.builder()
                .data(ExecutiveService.create(ExecutiveVO))
                .status(200)
                .message("Executive Created Successfully")
                .build();
    }

    @GetMapping(value = "/{id}")
    public ExecutiveVO view(@PathVariable Integer id) {
        return ExecutiveService.view(id);
    }

    @PutMapping(value = "/{id}")
    public ExecutiveVO update(@Valid @RequestBody ExecutiveVO ExecutiveVO, @PathVariable Integer id) {
        return ExecutiveService.update(id, ExecutiveVO);
    }


    @GetMapping(value = "/loans/{code}")
    public ResponseVO loans(@PathVariable String code) {
        return ResponseVO.builder()
                .data(ExecutiveService.getLoans(code))
                .status(200)
                .message("Executive Loan List")
                .build();
    }

    @PutMapping(value = "/loans/apply/{loanId}/{bCode}")
    public ResponseVO apply(@PathVariable Long loanId, @PathVariable String bCode) {
        return ResponseVO.builder()
                .data(ExecutiveService.updateLoan(loanId, bCode))
                .status(200)
                .message("Loan Application sent to bank")
                .build();
    }
}
