package com.kilpi.finayo.Repository;

import com.kilpi.finayo.Domain.BusinessTypeEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BusinessTypeEntityRepository extends JpaRepository<BusinessTypeEntity, Integer> {
}