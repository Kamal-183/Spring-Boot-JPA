package com.kilpi.finayo.Service.impl;

import com.kilpi.finayo.Domain.Loan;
import com.kilpi.finayo.Domain.LoanEntity;
import com.kilpi.finayo.Domain.VehicleEntity;
import com.kilpi.finayo.Repository.LoanRepository;
import com.kilpi.finayo.Repository.ExecutiveRepository;
import com.kilpi.finayo.Repository.VehicleRepository;
import com.kilpi.finayo.Service.LoanService;
import com.kilpi.finayo.VO.LoanVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class LoanServiceImpl implements LoanService {

    @Autowired
    LoanRepository loanRepository;

    @Autowired
    ExecutiveRepository ExecutiveRepository;

    @Autowired
    VehicleRepository vehicleRepository;

    @Override
    public List<LoanVO> load() {
        return loanRepository.findAll().stream().map(Loan::toVo).collect(Collectors.toList());
    }

    @Override
    public LoanVO create(LoanVO loanVO) {
        return null;
    }

    @Override
    public LoanVO view(Integer id) {
        return null;
    }

    @Override
    public LoanVO update(Integer id, LoanVO loanVO) {
        return null;
    }

	@Override
	public Integer LoanCount() {
		return loanRepository.findAll().size();
	}

}
