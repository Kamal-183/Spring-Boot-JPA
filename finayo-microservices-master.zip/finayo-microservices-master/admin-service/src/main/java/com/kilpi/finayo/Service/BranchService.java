package com.kilpi.finayo.Service;

import com.kilpi.finayo.VO.BranchDropdownVO;
import com.kilpi.finayo.VO.BranchVO;
import com.kilpi.finayo.VO.OrgVO;

import java.util.List;

public interface BranchService {

    List<BranchVO> load(Integer limit);

    BranchVO create(BranchVO branchVO);

    BranchVO view(Integer id);

    List<BranchVO> update(Integer id, BranchVO branchVO);

    List<BranchDropdownVO> loadExecutiveBranch();
    
    Integer BranchCount();
}
