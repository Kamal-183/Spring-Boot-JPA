package com.kilpi.finayo.VO;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProfileVO {
	private Long profileId;
	private String name;
	private String country;
	private String postal;
	private String email;
	private String phoneNo;
	private String nickName;
	private String city;
	private String officeAddress;
	private String orgName;
	private String orgType;
	private Double cibil;
	private Integer executiveId;
	private String panNo;
	private LoanVO loanVO;

}
