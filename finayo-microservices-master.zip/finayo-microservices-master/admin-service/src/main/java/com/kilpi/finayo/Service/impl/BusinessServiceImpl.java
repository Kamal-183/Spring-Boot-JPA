package com.kilpi.finayo.Service.impl;

import com.kilpi.finayo.Domain.BranchEntity;
import com.kilpi.finayo.Domain.BusinessTypeEntity;
import com.kilpi.finayo.Repository.BranchRepository;
import com.kilpi.finayo.Repository.BusinessTypeEntityRepository;
import com.kilpi.finayo.Service.BranchService;
import com.kilpi.finayo.Service.BusinessService;
import com.kilpi.finayo.VO.BranchVO;
import com.kilpi.finayo.VO.OptionsVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class BusinessServiceImpl implements BusinessService {

    @Autowired
    BusinessTypeEntityRepository businessTypeEntityRepository;

    @Override
    public List<OptionsVO> load() {
        return businessTypeEntityRepository.findAll().stream().map(BusinessTypeEntity::toVo).collect(Collectors.toList());
    }

    @Override
    public OptionsVO create(OptionsVO optionsVO) {
        BusinessTypeEntity entity = new BusinessTypeEntity();
        entity.setLabel(optionsVO.getLabel());
        entity.setValue(optionsVO.getValue());
        return businessTypeEntityRepository.save(entity).toVo();
    }

}
