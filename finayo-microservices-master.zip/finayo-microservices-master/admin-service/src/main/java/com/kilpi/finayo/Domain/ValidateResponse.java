package com.kilpi.finayo.Domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ValidateResponse {
	
	private String kycStatus;
	private String status;
	private String message;
	private KYCResult kycResult;
	private String responseCode;
	private String requestTimestamp;
	private String responseTimestamp;
	private String decentroTxnId;

}
