package com.kilpi.finayo.Domain;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;


@Entity
@Table(name = "dsa")
@Getter
@Setter
@NoArgsConstructor
public class DSAEntity {
        @Id
        @GeneratedValue(strategy= GenerationType.IDENTITY)
        private Integer id;

        @Column(name = "name")
        private String name;


        @Column(name = "unique_name")
        private String uniqueName;

        @Column(name = "category")
        private String category;
}
