package com.kilpi.finayo.Repository;

import com.kilpi.finayo.Domain.ExecutiveEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ExecutiveRepository extends JpaRepository<ExecutiveEntity, Integer> {
    Optional<ExecutiveEntity> findByCode(String code);
}
