package com.kilpi.finayo.Controller;


import java.io.IOException;
import java.util.Map;

import javax.validation.constraints.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.kilpi.finayo.Service.ClientService;
import com.kilpi.finayo.VO.Cibil.CbilVO;

@Validated
@RestController
@RequestMapping("client")
public class ClientController {

    @Autowired
    private ClientService clientService;
    
 
    @PostMapping
    public CbilVO load(@RequestBody CbilVO cbil) throws IOException {
        return clientService.loadCbil(cbil);
    }
    
    @GetMapping(value = "/aadhar/init")
    public Map<String, Object > validateAdhar() throws IOException {
        return clientService.initializeAadharSession();
    }

    @GetMapping(value = "aadhar/otp")
    public Map<String, Object > generateOtp(@RequestParam Integer id, @RequestParam String adharNum,@RequestParam String captcha) throws IOException {
        return clientService.generateOtp(id, adharNum, captcha);
    }

    @GetMapping(value = "/aadhar/submit")
    public Map<String, Object > validateAdhar(@RequestParam Integer id, @RequestParam String otp) throws IOException {
        return clientService.validateAdhar(id,otp);
    }
    

    
    @GetMapping(value = "aadhar/reload")
    public Map<String, Object > reloadCaptcha(@RequestParam Integer id) throws IOException {
        return clientService.reloadCaptcha(id);
    }
    
    @GetMapping(value = "/validate/pan")
    public Map<String, Object > validatePan(@RequestParam String pan) throws IOException {
        return clientService.validatePan(pan);
    }
    
    @GetMapping(value = "/validate/dl")
    public Map<String, Object > validatedl(@RequestParam String dl,@Pattern(regexp ="^\\d{4}\\-(0?[1-9]|1[012])\\-(0?[1-9]|[12][0-9]|3[01])$",message = "enter in yyyy-mm-dd") String date) throws IOException
    {
        return clientService.validateDL(dl,date);
    }
    
    @GetMapping(value = "/fetch/cibil")
    public Map<String, Object > fetchCibil(@RequestParam String name,String mobile) throws IOException {
        return clientService.getCibil(name, mobile);
    }
    

}
