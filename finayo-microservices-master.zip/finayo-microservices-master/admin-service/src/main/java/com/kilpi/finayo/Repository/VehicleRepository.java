package com.kilpi.finayo.Repository;

import com.kilpi.finayo.Domain.VehicleEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VehicleRepository extends JpaRepository<VehicleEntity, Integer> {
}
