package com.kilpi.finayo.Service;

import com.kilpi.finayo.VO.BranchVO;
import com.kilpi.finayo.VO.OptionsVO;

import java.util.List;

public interface ShowroomService {

    List<OptionsVO> load();

    OptionsVO create(OptionsVO optionsVO);

}
