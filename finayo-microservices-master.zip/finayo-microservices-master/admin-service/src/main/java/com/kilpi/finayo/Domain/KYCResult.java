package com.kilpi.finayo.Domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class KYCResult {
	
	private String idNumber;
	private String idStatus;
	private String name;

}
