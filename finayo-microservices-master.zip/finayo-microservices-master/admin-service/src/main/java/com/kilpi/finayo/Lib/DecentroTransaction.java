package com.kilpi.finayo.Lib;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kilpi.finayo.Config.DecentroProperties;
import com.kilpi.finayo.Constant.APIConstants;

import okhttp3.Headers;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;

@Service
public class DecentroTransaction {
	
	@Autowired
	DecentroProperties decentroProperties;
	
	public ResponseBody generateApi(Map<String,Object> requestData,String doctype,String subtype) throws IOException {
		
		OkHttpClient client = new OkHttpClient();
		MediaType mediaType = MediaType.parse("application/json");
		String json = new ObjectMapper().writeValueAsString(requestData);
		RequestBody body = RequestBody.create(json,mediaType);
		Map<String, String> header = new HashMap<>();
		header.put("Accept", "application/json");
		header.put("Content-Type", "application/json");
		header.put("client_id", decentroProperties.getClientId());
		header.put("client_secret", decentroProperties.getClientSecret());
		header.put("module_secret", decentroProperties.getModuleSecret());
		String path = null;
		switch (doctype) {
		case "AADHAAR":
			if(subtype=="initializeAadharSession")
				path=APIConstants.AADHAAR_SESSION_PATH;
			else if(subtype=="generateOtp")
				path=APIConstants.AADHAAR_OTP_PATH;
			else if(subtype=="validateAdhar") 
				path=APIConstants.AADHAAR_VALIDATE_PATH;
			else if(subtype=="reloadCaptcha") 
				path=APIConstants.CAPTCHA_RELOAD_PATH;
			break;
		case "PAN":
		case "DRIVING_LICENSE":
			path=APIConstants.DOC_VALIDATE_PATH;
			break;
		case "CR":
			path = APIConstants.CIBIL_PATH;
			header.put("provider_secret", decentroProperties.getProviderSecret());
			header.put("module_secret", decentroProperties.getFinanceModule());
			break;
		}
		Headers headerInfo = Headers.of(header);
		Request request = new Request.Builder()
		    	  .url(decentroProperties.getUrl()+path)
		    	  .post(body)
		    	  .headers(headerInfo)
		    	  .build();
    	    	ResponseBody response = client.newCall(request).execute().body();
				System.out.print(response);
    	    	return response;
		
	}
}
