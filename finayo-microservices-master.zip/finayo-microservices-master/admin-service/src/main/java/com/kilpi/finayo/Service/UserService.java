package com.kilpi.finayo.Service;

import com.kilpi.finayo.Domain.BankEntity;
import com.kilpi.finayo.Domain.ExecutiveEntity;

public interface UserService {
   
	ExecutiveEntity getExecutive();
   
    BankEntity getBankDetails();

    BranchService getBranchDetails();
}
