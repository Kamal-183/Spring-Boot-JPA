package com.kilpi.finayo.Config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@Data
@ConfigurationProperties(prefix = "app.auth")
public class AppProperties {

    private String tokenSecret;

    private long tokenExpirationMsec;

}