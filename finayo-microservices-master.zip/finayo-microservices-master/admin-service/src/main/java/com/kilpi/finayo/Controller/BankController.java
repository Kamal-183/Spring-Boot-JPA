package com.kilpi.finayo.Controller;

import com.kilpi.finayo.Service.BankService;
import com.kilpi.finayo.Service.ExecutiveService;
import com.kilpi.finayo.VO.BankVO;
import com.kilpi.finayo.VO.ExecutiveVO;
import com.kilpi.finayo.VO.ResponseVO;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("lender")
public class BankController {

    @Autowired
    private BankService bankService;

    @GetMapping(value = "/list")
    public ResponseVO load() {
        return ResponseVO.builder()
                .data(bankService.load())
                .status(200)
                .message("List Of Lenders")
                .build();
    }

    @PostMapping(value = "/create")
    public ResponseVO create(@Valid @RequestBody BankVO bankVO) {
        return ResponseVO.builder()
                .data(bankService.create(bankVO))
                .status(200)
                .message("Lender Created Successfully")
                .build();
    }
//
//    @GetMapping(value = "/{id}")
//    public ExecutiveVO view(@PathVariable Integer id) {
//        return ExecutiveService.view(id);
//    }
//
//    @PutMapping(value = "/{id}")
//    public ExecutiveVO update(@RequestBody ExecutiveVO ExecutiveVO, @PathVariable Integer id) {
//        return ExecutiveService.update(id, ExecutiveVO);
//    }

    @GetMapping(value = "/cibil/{score}")
    public ResponseVO getBanksByCibil(@PathVariable(name = "score") Double score) {
        return ResponseVO.builder()
                .data(bankService.getBanksByCibil(score))
                .status(200)
                .message("List Of Lenders")
                .build();
    }
}
