package com.kilpi.finayo.Controller;

import com.kilpi.finayo.Service.BranchService;
import com.kilpi.finayo.Service.BusinessService;
import com.kilpi.finayo.VO.BranchVO;
import com.kilpi.finayo.VO.OptionsVO;
import com.kilpi.finayo.VO.ResponseVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("bu")
public class BusinessController {

    @Autowired
    private BusinessService businessService;

    @GetMapping(value = "/list")
    public ResponseVO load() {
        return ResponseVO.builder()
                .data(businessService.load())
                .status(200)
                .message("List of Business types")
                .build();
    }

    @PostMapping(value = "/create")
    public ResponseVO create(@RequestBody OptionsVO optionsVO) {
        return ResponseVO.builder()
                .data(businessService.create(optionsVO))
                .status(200)
                .message("Business type Created Successfully")
                .build();
    }



}
