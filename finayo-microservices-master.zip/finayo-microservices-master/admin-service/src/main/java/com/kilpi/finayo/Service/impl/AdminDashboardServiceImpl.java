package com.kilpi.finayo.Service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kilpi.finayo.Repository.BranchRepository;
import com.kilpi.finayo.Repository.ExecutiveRepository;
import com.kilpi.finayo.Repository.LoanRepository;
import com.kilpi.finayo.Service.AdminDashboardService;
import com.kilpi.finayo.Service.BranchService;
import com.kilpi.finayo.Service.ExecutiveService;
import com.kilpi.finayo.Service.LoanService;
import com.kilpi.finayo.VO.Total;

@Service
public class AdminDashboardServiceImpl implements AdminDashboardService {

	@Autowired
	BranchRepository branchRepository;
	
	@Autowired
	ExecutiveRepository executiveRepository;
	
	@Autowired
	LoanRepository loanRepository;
	
	@Override
	public Total total() {
		Total total = new Total();
		total.setBranch(branchRepository.count());
		total.setExecutive(executiveRepository.count());
		total.setLoanApplications(loanRepository.count());
		return total;
	}

}
