package com.kilpi.finayo.Repository;

import com.kilpi.finayo.Domain.ShowroomTypeEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ShowroomTypeEntityRepository extends JpaRepository<ShowroomTypeEntity, Integer> {
}