package com.kilpi.finayo.VO;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Total {
	
	private Long Branch;
	private Long Executive;
	private Long LoanApplications;
	

}
