package com.kilpi.finayo.Repository;

import com.kilpi.finayo.Domain.BankEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Collection;
import java.util.List;

public interface BankRepository extends JpaRepository<BankEntity, Integer> {

    @Query("SELECT b FROM BankEntity b WHERE b.acptCibil <= ?1")
    List<BankEntity> findByMinCibil(Double score);

    BankEntity findByCode(String bCode);
}