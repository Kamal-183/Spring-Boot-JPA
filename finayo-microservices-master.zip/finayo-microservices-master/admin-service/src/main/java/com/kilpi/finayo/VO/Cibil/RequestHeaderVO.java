package com.kilpi.finayo.VO.Cibil;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Arrays;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RequestHeaderVO {

    private String CustomerId = "8060";
    private String UserId = "STS_CRECCR";
    private String Password = "W3#QeicsB";
    private String ExecutiveNumber = "007FZ01996";
    private String SecurityCode = "2IC";
    private Boolean active;
    private List<String> ProductCode = Arrays.asList("CCR");
}
