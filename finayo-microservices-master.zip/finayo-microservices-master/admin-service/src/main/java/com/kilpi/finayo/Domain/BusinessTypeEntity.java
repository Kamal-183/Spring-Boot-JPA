package com.kilpi.finayo.Domain;


import com.kilpi.finayo.VO.OptionsVO;
import com.kilpi.finayo.VO.OrgVO;
import lombok.Data;

import javax.persistence.*;
import java.util.List;

@Data
@Entity
@Table(name = "business_type")
public class BusinessTypeEntity {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "value")
    private String value;

    @Column(name = "label")
    private String label;

    public OptionsVO toVo() {
        return OptionsVO.builder()
                .id(id)
                .label(label)
                .value(value)
                .build();
    }

}

