package com.kilpi.finayo.Controller;

import com.kilpi.finayo.Service.BranchService;
import com.kilpi.finayo.Service.ShowroomService;
import com.kilpi.finayo.VO.BranchVO;
import com.kilpi.finayo.VO.OptionsVO;
import com.kilpi.finayo.VO.ResponseVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("showroom")
public class ShowroomController {

    @Autowired
    private ShowroomService showroomService;

    @GetMapping(value = "/list")
    public ResponseVO load() {
        return ResponseVO.builder()
                .data(showroomService.load())
                .status(200)
                .message("List of showroom types")
                .build();
    }

    @PostMapping(value = "/create")
    public ResponseVO create(@RequestBody OptionsVO optionsVO) {
        return ResponseVO.builder()
                .data(showroomService.create(optionsVO))
                .status(200)
                .message("Showroom type Created Successfully")
                .build();
    }


}
