package com.kilpi.finayo.Service;

public interface VehicleService {
}
