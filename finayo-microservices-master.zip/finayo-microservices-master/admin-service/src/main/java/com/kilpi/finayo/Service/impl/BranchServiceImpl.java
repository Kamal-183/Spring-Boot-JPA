package com.kilpi.finayo.Service.impl;

import com.kilpi.finayo.Domain.BranchEntity;
import com.kilpi.finayo.Domain.BusinessTypeEntity;
import com.kilpi.finayo.Domain.ShowroomTypeEntity;
import com.kilpi.finayo.Repository.BranchRepository;
import com.kilpi.finayo.Repository.BusinessTypeEntityRepository;
import com.kilpi.finayo.Repository.ShowroomTypeEntityRepository;
import com.kilpi.finayo.Service.BranchService;
import com.kilpi.finayo.VO.BranchDropdownVO;
import com.kilpi.finayo.VO.BranchVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.awt.print.Pageable;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class BranchServiceImpl implements BranchService {

    @Autowired
    BranchRepository branchRepository;

    @Autowired
    BusinessTypeEntityRepository businessTypeEntityRepository;

    @Autowired
    ShowroomTypeEntityRepository showroomTypeEntityRepository;

    @Override
    public List<BranchVO> load(Integer limit) {
        if(limit != null){
            List<BranchVO> list = branchRepository.findAll().stream().map(BranchEntity::toVo).collect(Collectors.toList());

            Collections.shuffle(list);
            return list.subList(0, limit);
        }
        return branchRepository.findAll().stream().map(BranchEntity::toVo).collect(Collectors.toList());
    }

    @Override
    public BranchVO create(BranchVO branchVO) {

//        Optional<ShowroomTypeEntity> showroomTypeEntity = showroomTypeEntityRepository.findById(branchVO.getShowroomTypes().get());
        Optional<BusinessTypeEntity> businessTypeEntity = businessTypeEntityRepository.findById(branchVO.getBusinessType().getId());
        BranchEntity entity = new BranchEntity();
        entity.setName(branchVO.getName());
        entity.setAddress(branchVO.getAddress());
        entity.setCity(branchVO.getCity());
        entity.setMobile(branchVO.getMobile());
        entity.setBusinessType(businessTypeEntity.get());
        //entity.setShowroomTypes(branchVO.getShowroomTypes());
        entity.setActive(branchVO.getActive());
        entity = branchRepository.save(entity);

        String code = branchVO.getName().substring(0,2).toUpperCase();
        code += branchVO.getCity().substring(0,2).toUpperCase();
        code += String.format("%04d", entity.getId());

        entity.setCode(code);
        return branchRepository.save(entity).toVo();
    }

    @Override
    public BranchVO view(Integer id) {

        Optional<BranchEntity> isBranch = branchRepository.findById(id);
        if(isBranch.isPresent()){
            return isBranch.get().toVo();
        }
        return null;
    }

    @Override
    public List<BranchVO> update(Integer id, BranchVO branchVO) {
        Optional<BranchEntity> isBranch = branchRepository.findById(id);
        if(isBranch.isPresent()){
            BranchEntity entity = isBranch.get();

//            Optional<ShowroomTypeEntity> showroomTypeEntity = showroomTypeEntityRepository.findById(branchVO.getShowroomTypes()./);
            Optional<BusinessTypeEntity> businessTypeEntity = businessTypeEntityRepository.findById(branchVO.getBusinessType().getId());

            entity.setName(branchVO.getName());
            entity.setAddress(branchVO.getAddress());
            entity.setCity(branchVO.getCity());
            entity.setMobile(branchVO.getMobile());
            entity.setBusinessType(businessTypeEntity.get());
            //entity.setShowroomTypes(branchVO.getShowroomTypes());
            entity.setActive(branchVO.getActive());
            branchRepository.save(entity);
        }
        return null;
    }

    @Override
    public List<BranchDropdownVO> loadExecutiveBranch() {
        return branchRepository.findAll().stream().map(BranchEntity::toDropdownVo).collect(Collectors.toList());

    }

	@Override
	public Integer BranchCount() {
		 return branchRepository.findAll().size();
	}
}
