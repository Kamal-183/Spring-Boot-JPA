package com.kilpi.finayo.Service;

import com.kilpi.finayo.VO.Total;

public interface AdminDashboardService {
	
	Total total();

}
