package com.kilpi.finayo.Constant;

import lombok.Getter;
import lombok.Data;

public enum DocType {

	    AADHAR("Aadhar","AADHAAR"),
	    PAN("Pan","PAN"),
	    DL("Dl","DRIVING_LICENSE"),
		CR("CR","CR");

		
	    @Getter
	    private String name;
	    @Getter
	    private String type;

	    DocType(String name, String type) {
	        this.name = name;
	        this.type = type;
	        
	    }
	    public static DocType from(final String code) {
	        if (code == null) {
	            return null;
	        }
	        for (DocType val : DocType.values()) {
	            if (val.type.equalsIgnoreCase(code)) {
	                return val;
	            }
	        }
	        throw new IllegalArgumentException("Invalid access level");
	    }
	    }
	