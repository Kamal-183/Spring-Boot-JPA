package com.kilpi.finayo.VO;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

import javax.validation.constraints.Email;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ExecutiveVO {

    private Integer id;
    private String code;
    @NotBlank
    @Size(min = 3, max = 25, message = "first name must be of min 3 length")
    private String firstName;
    @NotBlank
    @Size(min = 3, max = 25, message = "last name must be of min 3 length")
    private String lastName;
    @NotBlank
    @Pattern(regexp = "^([1-9]){9}[0-9]$", message = "number must be of 10 length")
    private String mobile;
    @NotBlank
    @Size(min = 5, max = 250, message = "address must be of min 5")
    private String address;
    @NotBlank
    @Size(min=3, max = 25, message = "city must be between 3 and 25")
    private String city;
    @NotBlank
    @Email(message = "Invalid Email")
    private String email;
    private BranchVO branch;
}
