package com.kilpi.finayo.Domain;

import com.kilpi.finayo.VO.VehicleVO;
import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(name = "dsa_vehicle")
public class VehicleEntity {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    Integer id;

    @Column(name = "name")
    String name;

    @Column(name = "ex_showroom")
    String exShowroom;

    @Column(name = "on_road_price")
    String onRoadPrice;

    @Column(name = "down_payment")
    String downPayment;

    public VehicleVO toVo() {
        return VehicleVO.builder()
                .id(id)
                .name(name)
                .downPayment(downPayment)
                .exShowroom(exShowroom)
                .onRoadPrice(onRoadPrice)
                .build();
    }
}
