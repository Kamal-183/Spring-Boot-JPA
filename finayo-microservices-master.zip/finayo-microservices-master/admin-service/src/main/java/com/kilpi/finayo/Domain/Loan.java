package com.kilpi.finayo.Domain;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.kilpi.finayo.Constant.LoanStatus;
import com.kilpi.finayo.VO.LoanVO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.LinkedList;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "loan_details")
public class Loan {

	@Id
	@Column(name = "lid")
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Long lId;

	@Column(name = "loan_amount")
	private Double loanAmount;

	@Column(name = "down_payment")
	private Double downPayment;

	@Column(name = "tenure")
	private Integer tenure;

	@Column(name = "interest_rate")
	private Double interestRate;

	@Column(name = "vehicle_amount")
	private Double vehicleAmount;

	@Column(name = "applied_date")
	private LocalDateTime appDate;

	@Column(name = "complete_date")
	private LocalDateTime completeDate;

	@Column(name = "statement_path")
	private String stmntPath;

	@Column(name = "receipt_path")
	private String recptPath;

	@Enumerated(EnumType.STRING)
	@Column(name = "status")
	private LoanStatus LoanStatus;
	
	@Column(name = "createdby")
	private LocalDateTime createdBy;
	
	@Column(name = "updatedby")
	private LocalDateTime updatedby;

	@OneToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "profile_id", nullable = false)
	private Profile profile;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "bank_id")
	private BankEntity bank;

	@JsonBackReference
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "loan")
	@LazyCollection(LazyCollectionOption.FALSE)
	private List<BankLoanEntity> banks = new LinkedList<>();
	
	public LoanVO toVo() {
        return LoanVO.builder()
                .loanId(lId)
                .loanAmount(loanAmount)
                .downPayment(downPayment)
                .tenure(tenure)
                .interestRate(interestRate)
                .vehicleAmount(vehicleAmount)
                .appDate(appDate)
                .completeDate(completeDate)
                .stmntPath(stmntPath)
                .recptPath(recptPath)
                .loanStatus(LoanStatus)
                .profileVO(profile!=null?profile.toVo():null)
                .build();
    }
	
	
}
