package com.kilpi.finayo.Service;

import java.io.IOException;
import java.util.Map;

import com.kilpi.finayo.Domain.ValidateResponse;
import com.kilpi.finayo.VO.Cibil.CbilVO;

public interface ClientService {

    CbilVO loadCbil(CbilVO cbil) throws IOException;

    Map<String, Object> validatePan(String panNum) throws IOException;

    Map<String, Object > validateDL(String DL,String date) throws IOException;


    Map<String, Object> initializeAadharSession() throws IOException;
    Map<String, Object> generateOtp(Integer id, String adharNum,String captcha) throws IOException;
    Map<String, Object> validateAdhar(Integer id, String otp) throws IOException;
    Map<String, Object> reloadCaptcha(Integer id) throws IOException;

    Map<String, Object > getCibil(String name,String mobile) throws IOException;
}
