package com.kilpi.finayo.Domain;

import com.kilpi.finayo.VO.ProfileVO;
import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(name = "profile_details")
public class Profile {

	@Id
	@Column(name = "pid")
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Long pId;

	@Column(name = "name")
	private String name;

	@Column(name = "country")
	private String country;

	@Column(name = "postal")
	private String postal;

	@Column(name = "email")
	private String email;

	@Column(name = "phone_no")
	private String phoneNo;

	@Column(name = "nick_name")
	private String nickName;

	@Column(name = "city")
	private String city;

	@Column(name = "office_address")
	private String officeAddress;

	@Column(name = "organisation_name")
	private String orgName;

	@Column(name = "organisation_type")
	private String orgType;


	@Column(name = "cibil")
	private Double cibil;

	@Column(name = "executive_id")
	private Integer executiveId;

	@Column(name = "pan_no")
	private String panNo;
	
	public ProfileVO toVo() {
        return ProfileVO.builder()
                .profileId(pId)
                .name(name)
                .country(country)
                .postal(postal)
                .email(email)
                .phoneNo(phoneNo)
                .nickName(nickName)
                .city(city)
                .officeAddress(officeAddress)
                .orgName(orgName)
                .orgType(orgType)
                .cibil(cibil)
                .executiveId(executiveId)
                .panNo(panNo)
                .build();
    }
	

	
}
