package com.kilpi.finayo.Constant;

public class APIConstants {

	public static final String AADHAAR_SESSION_PATH="/v2/kyc/aadhaar_connect";
	public static final String AADHAAR_OTP_PATH="/v2/kyc/aadhaar_connect/otp";
	public static final String AADHAAR_VALIDATE_PATH="/v2/kyc/aadhaar_connect/otp/validate";
	public static final String DOC_VALIDATE_PATH="/kyc/public_registry/validate";
	public static final String CAPTCHA_RELOAD_PATH="/v2/kyc/aadhaar_connect/captcha/reload";
	public static final String CIBIL_PATH="/v2/financial_services/credit_bureau/credit_report";
}
