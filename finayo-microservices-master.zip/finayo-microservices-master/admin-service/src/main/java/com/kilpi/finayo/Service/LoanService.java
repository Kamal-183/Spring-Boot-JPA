package com.kilpi.finayo.Service;

import com.kilpi.finayo.VO.LoanVO;

import java.util.List;

public interface LoanService {
    List<LoanVO> load();

    LoanVO create(LoanVO loanVO);

    LoanVO view(Integer id);

    LoanVO update(Integer id, LoanVO loanVO);
    
    Integer LoanCount();
}