package com.kilpi.finayo.Domain;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.kilpi.finayo.VO.BankVO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;
import org.joda.time.DateTime;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.LinkedList;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "decentro_transaction_table")
public class DecentroTransactionEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Integer id;

    @Column(name = "client_id")
    private String clientId;

    @Column(name = "type")
    private String type;

    @Column(name = "transaction_id")
    private String transactionId;

    @Column(name = "response")
    private String response;

    @Column(name = "request")
    private String request;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "status_code")
    private String statusCode;
}
