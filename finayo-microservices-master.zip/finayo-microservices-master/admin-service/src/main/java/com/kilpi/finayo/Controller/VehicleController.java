package com.kilpi.finayo.Controller;


import com.kilpi.finayo.Service.BranchService;
import com.kilpi.finayo.VO.OrgVO;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("vehicle")
public class VehicleController {
    

}
