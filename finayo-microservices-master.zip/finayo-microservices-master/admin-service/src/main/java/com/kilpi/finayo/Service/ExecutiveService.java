package com.kilpi.finayo.Service;


import com.kilpi.finayo.VO.ExecutiveVO;
import com.kilpi.finayo.VO.LoanVO;
import com.kilpi.finayo.VO.OrgVO;

import java.util.List;

public interface ExecutiveService {
    List<ExecutiveVO> load(Integer limit);

    ExecutiveVO create(ExecutiveVO executiveVO);

    ExecutiveVO view(Integer id);

    ExecutiveVO update(Integer id, ExecutiveVO executiveVO);

    List<LoanVO> getLoans(String code);

    LoanVO updateLoan(Long loanId, String bCode);
    
    Integer ExecutiveCount();
}
