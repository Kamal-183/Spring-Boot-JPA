package com.kilpi.finayo.Service.impl;

import com.kilpi.finayo.Config.DecentroProperties;
import com.kilpi.finayo.Constant.APIConstants;
import com.kilpi.finayo.Constant.DocType;
import com.kilpi.finayo.Domain.DecentroTransactionEntity;
import com.kilpi.finayo.Domain.ValidateResponse;
import com.kilpi.finayo.Lib.DecentroTransaction;
import com.kilpi.finayo.Repository.DecentroTransactionRepository;
import com.kilpi.finayo.Service.ClientService;
import com.kilpi.finayo.VO.Cibil.*;
import okhttp3.*;
import org.codehaus.jackson.map.ObjectMapper;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.*;

@Service
public class ClientServiceImpl implements ClientService {

	@Autowired
	DecentroProperties decentroProperties;

	@Autowired
	ObjectMapper mapper;

	@Autowired
	DecentroTransactionRepository decentroTransactionRepository;

	@Autowired
	DecentroTransaction decentroTransaction;

	private static final String CONCENT = "For bank account purpose only";

	private final OkHttpClient httpClient = new OkHttpClient();
	public static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");

	@Override
	public CbilVO loadCbil(CbilVO cbil) throws IOException {
		ObjectMapper obj = new ObjectMapper();

		List<FamilyDetailsVO> familyDetails = new ArrayList<>();
		List<InquiryAddressesVO> addresses = new ArrayList<>();
		List<IDDetailsVO> idDetails = new ArrayList<>();
		List<InquiryPhonesVO> phones = new ArrayList<>();
		List<ScoreVO> scores = new ArrayList<>();

		addresses.add(InquiryAddressesVO.builder().seq("1").AddressType(Arrays.asList("H"))
				.AddressLine1("A P MALWADI KALBE TARF THANE KARAVEER KOLHAPUR 416007").State("MH").Postal("416007")
				.build());

		phones.add(InquiryPhonesVO.builder().seq("1").Number("9767348858").PhoneType(Arrays.asList("M")).build());

		phones.add(InquiryPhonesVO.builder().seq("2").Number("").PhoneType(Arrays.asList("M")).build());

		idDetails.add(IDDetailsVO.builder().seq("1").IDType("T").IDValue("BYWPP5444A").Source("Inquiry").build());

		idDetails.add(IDDetailsVO.builder().seq("2").IDType("P").IDValue("").Source("Inquiry").build());

		idDetails.add(IDDetailsVO.builder().seq("3").IDType("V").IDValue("BYWPP5444A").Source("Inquiry").build());

		idDetails.add(IDDetailsVO.builder().seq("4").IDType("D").IDValue("").Source("Inquiry").build());

		idDetails.add(IDDetailsVO.builder().seq("5").IDType("M").IDValue("").Source("Inquiry").build());

		idDetails.add(IDDetailsVO.builder().seq("6").IDType("R").IDValue("").Source("Inquiry").build());

		idDetails.add(IDDetailsVO.builder().seq("7").IDType("O").IDValue("").Source("Inquiry").build());

		familyDetails.add(FamilyDetailsVO.builder().seq("1").AdditionalNameType("KA02")
				.AdditionalName("BHARAT KRUSHNAT PATIL").build());

		familyDetails.add(FamilyDetailsVO.builder().seq("1").AdditionalNameType("KA01").AdditionalName("").build());

		scores.add(ScoreVO.builder().Type("ERS").Version("3.1").build());

		cbil.setInquiryPurpose("0E");
		cbil.setFirstName("SANGITA");
		cbil.setLastName("BHARAT");
		cbil.setMiddleName("PATIL");
		cbil.setDOB("1978-10-12");
		cbil.setInquiryAddresses(addresses);
		cbil.setIDDetails(idDetails);
		cbil.setInquiryPhones(phones);
		cbil.setScore(scores);
		cbil.setMFIDetails(MFIDetailsVO.builder().FamilyDetails(familyDetails).build());

		RequestHeaderVO header = new RequestHeaderVO();

		String data = obj.writeValueAsString(cbil);
		// form parameters
		RequestBody formBody = RequestBody.create(data, JSON);
		Request request = new Request.Builder().url("https://ists.equifax.co.in/cir360service/cir360report")
				.addHeader("User-Agent", "OkHttp Bot").post(formBody).build();

		return cbil;
	}

	@SuppressWarnings("unchecked")
	@Override
	public Map<String, Object> initializeAadharSession() throws IOException {

        String nameofCurrMethod = new Throwable()
                					.getStackTrace()[0]
                					.getMethodName();
		DecentroTransactionEntity transaction = new DecentroTransactionEntity();
		transaction.setClientId(decentroProperties.getClientId());
		transaction.setCreatedDate(LocalDateTime.now());
		transaction.setType(DocType.AADHAR.getType());

		Map<String, Object> requestData = new HashMap<>();
		requestData.put("consent", "Y");
		requestData.put("purpose", CONCENT);
		requestData.put("reference_id", "ASDF9927");

		ResponseBody response = decentroTransaction.generateApi(requestData, DocType.AADHAR.getType(), nameofCurrMethod);
		Map<String, Object> respData = mapper.readValue(response.string(), Map.class);

		Map<String, Object> initData = new HashMap<>();
		initData.put("txnId", respData.get("decentroTxnId").toString());

		String base64Encoded = ((LinkedHashMap) respData.get("data")).get("captchaImage").toString();

//		String captcha = decodeCaptcha.DecodeCaptchaFromBase64(base64Encoded);
		initData.put("captcha", base64Encoded);

		transaction.setTransactionId(respData.get("decentroTxnId").toString());
		transaction.setStatusCode(respData.get("responseCode").toString());
		Integer id = decentroTransactionRepository.save(transaction).getId();
		initData.put("id", id.toString());

		return initData;
	}

	@Override
	public Map<String, Object> generateOtp(Integer id, String adharNum, String captcha) throws IOException {

		Map<String, Object> initData = new HashMap<>();
		initData.put("id", id.toString());

		Optional<DecentroTransactionEntity> txn = decentroTransactionRepository.findById(id);

		Map<String, Object> requestData = new HashMap<>();
		requestData.put("reference_id", "ASDF1234");
		requestData.put("aadhaar_number", adharNum);
		requestData.put("consent", "Y");
		requestData.put("captcha", captcha);
		requestData.put("purpose", CONCENT);
		requestData.put("initiation_transaction_id", txn.get().getTransactionId());
        String nameofCurrMethod = new Throwable()
				.getStackTrace()[0]
				.getMethodName();
		ResponseBody response = decentroTransaction.generateApi(requestData, DocType.AADHAR.getType(), nameofCurrMethod);
		Map<String, Object> respData = mapper.readValue(response.string(), Map.class);
		return respData;
	}

	@Override
	public Map<String, Object> validateAdhar(Integer id, String otp) throws IOException {

		Optional<DecentroTransactionEntity> txn = decentroTransactionRepository.findById(id);

		Map<String, Object> init = initializeAadharSession();

		Map<String, Object> requestData = new HashMap<>();
		requestData.put("reference_id", "ZXCV9927");
		requestData.put("consent", true);
		requestData.put("purpose", CONCENT);
		requestData.put("initiation_transaction_id", txn.get().getTransactionId());
		requestData.put("otp", otp);
        String nameofCurrMethod = new Throwable()
				.getStackTrace()[0]
				.getMethodName();
		ResponseBody response = decentroTransaction.generateApi(requestData, DocType.AADHAR.getType(), nameofCurrMethod);
		Map<String, Object> respData = mapper.readValue(response.string(), Map.class);

		Map<String, Object> initData = new HashMap<>();

		return respData;
	}

	@Override
	public Map<String, Object> validatePan(String panNum) throws IOException {

		DecentroTransactionEntity transaction = new DecentroTransactionEntity();
		transaction.setClientId(decentroProperties.getClientId());
		transaction.setCreatedDate(LocalDateTime.now());
		transaction.setType(DocType.PAN.getType());
		Map<String, Object> requestData = new HashMap<>();
		requestData.put("reference_id", "0000-0000-0000-2125");
		requestData.put("document_type", DocType.PAN.getType());
		requestData.put("id_number", panNum.toUpperCase());
		requestData.put("consent", "Y");
		requestData.put("consent_purpose", CONCENT);
        String nameofCurrMethod = new Throwable()
				.getStackTrace()[0]
				.getMethodName();
		ResponseBody response = decentroTransaction.generateApi(requestData, DocType.PAN.getType(), nameofCurrMethod);

		Map<String, Object> respData = mapper.readValue(response.string(), Map.class);
		transaction.setTransactionId(respData.get("decentroTxnId").toString());
		transaction.setStatusCode(respData.get("responseCode").toString());
		decentroTransactionRepository.save(transaction);
		return respData;
	}

	@Override
	public Map<String, Object> validateDL(String DL, String date) throws IOException {
		
		DecentroTransactionEntity transaction = new DecentroTransactionEntity();
		transaction.setClientId(decentroProperties.getClientId());
		transaction.setCreatedDate(LocalDateTime.now());
		transaction.setType(DocType.DL.getType());
		Map<String, Object> requestData = new HashMap<>();
		requestData.put("reference_id", "0000-0000-0000-2115");
		requestData.put("document_type", DocType.DL.getType());
		requestData.put("id_number", DL.toUpperCase());
		requestData.put("consent", "Y");
		requestData.put("dob", date);// yyyy-mm-dd
		requestData.put("consent_purpose", CONCENT);
        String nameofCurrMethod = new Throwable()
				.getStackTrace()[0]
				.getMethodName();
		ResponseBody response = decentroTransaction.generateApi(requestData, DocType.DL.getType(), nameofCurrMethod);
		Map<String, Object> respData = mapper.readValue(response.string(), Map.class);
		transaction.setTransactionId(respData.get("decentroTxnId").toString());
		transaction.setStatusCode(respData.get("responseCode").toString());
		decentroTransactionRepository.save(transaction);
		return respData;
	}

	@Override
	public Map<String, Object> reloadCaptcha(Integer id) throws IOException {
		Optional<DecentroTransactionEntity> txn = decentroTransactionRepository.findById(id);

		Map<String, Object> requestData = new HashMap<>();
		requestData.put("reference_id", "ASDF1234");
		requestData.put("consent", "Y");
		requestData.put("purpose", CONCENT);
		requestData.put("initiation_transaction_id", txn.get().getId());
		String json = new ObjectMapper().writeValueAsString(requestData);
        String nameofCurrMethod = new Throwable()
				.getStackTrace()[0]
				.getMethodName();
		ResponseBody response = decentroTransaction.generateApi(requestData, DocType.AADHAR.getType(), nameofCurrMethod);

		Map<String, Object> respData = mapper.readValue(response.string(), Map.class);
		return respData;
	}

	@Override
	public Map<String, Object> getCibil(String name, String mobile) throws IOException {

		Integer count = decentroTransactionRepository.findByType(DocType.CR.getType());
		String refid = "0000000000000001";
		if (count != 0) {
			Long ref = (Long.parseLong(refid) + count);
			refid = String.format("%016d", ref);
		}
		DecentroTransactionEntity transaction = new DecentroTransactionEntity();
		transaction.setClientId(decentroProperties.getClientId());
		transaction.setCreatedDate(LocalDateTime.now());
		transaction.setType(DocType.CR.getType());

		Map<String, Object> requestData = new HashMap<>();
		requestData.put("reference_id", refid);
		requestData.put("name", name);
		requestData.put("mobile", mobile);
		requestData.put("inquiry_purpose", "PL");

		ResponseBody response = decentroTransaction.generateApi(requestData, DocType.CR.getType(), null);
		Map<String, Object> respData = mapper.readValue(response.string(), Map.class);
		transaction.setTransactionId(respData.get("decentroTxnId").toString());
		transaction.setStatusCode("200");// no response code in cibil
		decentroTransactionRepository.save(transaction);
		return respData;
	}
}
