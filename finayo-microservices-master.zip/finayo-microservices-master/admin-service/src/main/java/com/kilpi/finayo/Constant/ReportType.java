package com.kilpi.finayo.Constant;

public enum ReportType {
	month,week,year
}
