package com.kilpi.finayo.Domain;


import com.kilpi.finayo.VO.LoanVO;
import com.kilpi.finayo.VO.OrgVO;
import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(name = "dsa_loan")
public class LoanEntity {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    Integer id;

    @Column(name = "loan_id")
    String loanId;

    @Column(name = "score")
    String score;

    @Column(name = "interest")
    String interest;

    @Column(name = "tenure")
    String tenure;

    @Column(name = "business_type")
    String businessType;

    @Column(name = "loan_requirement")
    String loanRequirement;

    @Column(name = "pancard")
    String pancard;

    @Column(name = "name")
    String name;

    @Column(name = "dob")
    String dob;

    @Column(name = "father_name")
    String fatherName;

    @Column(name = "application_type")
    String applicationType;

    @Column(name = "salary")
    String salary;

    @Column(name = "organization_type")
    String organizationType;

    @Column(name = "company")
    String company;

    @Column(name = "gross_income")
    String grossIncome;

    @Column(name = "status")
    String status;

    @ManyToOne
    ExecutiveEntity Executive;

    @OneToOne
    VehicleEntity vehicle;

}
