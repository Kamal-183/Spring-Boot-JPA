package com.kilpi.finayo.Repository;

import com.kilpi.finayo.Domain.Loan;
import com.kilpi.finayo.Domain.LoanEntity;
import com.kilpi.finayo.VO.ExecutiveVO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface LoanRepository extends JpaRepository<Loan, Long> {

    @Query("SELECT l FROM Loan l WHERE l.profile.executiveId = ?1")
    List<Loan> findByExecutiveId(Integer id);
}
