package com.kilpi.finayo.VO;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.kilpi.finayo.Constant.LoanStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LoanVO {
	
	private Long loanId;
	private Double loanAmount;
	private Double downPayment;
	private Integer tenure;
	private Double interestRate;
	private Double vehicleAmount;
	private LocalDateTime appDate;
	private LocalDateTime completeDate;
	private String stmntPath;
	private String recptPath;
	private LoanStatus loanStatus;
	private ProfileVO profileVO;
	private List<BankVO> lenders;
}

