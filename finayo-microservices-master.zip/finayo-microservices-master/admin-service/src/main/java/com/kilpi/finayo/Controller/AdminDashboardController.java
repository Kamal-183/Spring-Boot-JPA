package com.kilpi.finayo.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kilpi.finayo.Service.AdminDashboardService;
import com.kilpi.finayo.VO.ResponseVO;

@RestController
@RequestMapping("admin/dashboard")
public class AdminDashboardController {
	
	@Autowired
	AdminDashboardService adminDashboardService;
	
	@GetMapping(value = "/")
	public ResponseVO total() {
        return ResponseVO.builder()
                .data(adminDashboardService.total())
                .status(200)
                .message("Total Data")
                .build();
	}

}
