package com.kilpi.finayo.Controller;

import com.kilpi.finayo.Service.BranchService;
import com.kilpi.finayo.VO.BranchVO;
import com.kilpi.finayo.VO.OrgVO;
import com.kilpi.finayo.VO.ResponseVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import javax.validation.Valid;

@RestController
@RequestMapping("branch")
public class BranchController {

    @Autowired
    private BranchService branchService;

    @GetMapping(value = "/list")
    public ResponseVO load(@PathVariable(name = "limit", required = false) Integer limit) {

        return ResponseVO.builder()
                .data(branchService.load(limit))
                .status(200)
                .message("Branch List")
                .build();

    }

    @PostMapping(value = "/create")
    public ResponseVO create(@Valid @RequestBody BranchVO branchVO) {

        return ResponseVO.builder()
                .data(branchService.create(branchVO))
                .status(200)
                .message("Branch Created Successfully")
                .build();
    }

    @GetMapping(value = "/{id}")
    public BranchVO view(@PathVariable Integer id) {
        return branchService.view(id);
    }

    @PutMapping(value = "/{id}")
    public List<BranchVO> update(@Valid @RequestBody BranchVO branchVo, @PathVariable Integer id) {
        return branchService.update(id, branchVo);
    }

    @GetMapping(value = "/executive/dropdown")
    public ResponseVO executiveDropdown() {

        return ResponseVO.builder()
                .data(branchService.loadExecutiveBranch())
                .status(200)
                .message("Branch List")
                .build();

    }

}
