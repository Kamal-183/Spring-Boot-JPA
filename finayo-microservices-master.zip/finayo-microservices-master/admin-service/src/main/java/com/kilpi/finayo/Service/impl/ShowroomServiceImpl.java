package com.kilpi.finayo.Service.impl;

import com.kilpi.finayo.Domain.BranchEntity;
import com.kilpi.finayo.Domain.ShowroomTypeEntity;
import com.kilpi.finayo.Repository.BranchRepository;
import com.kilpi.finayo.Repository.ShowroomTypeEntityRepository;
import com.kilpi.finayo.Service.BranchService;
import com.kilpi.finayo.Service.ShowroomService;
import com.kilpi.finayo.VO.BranchVO;
import com.kilpi.finayo.VO.OptionsVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ShowroomServiceImpl implements ShowroomService {

    @Autowired
    ShowroomTypeEntityRepository showroomTypeEntityRepository;

    @Override
    public List<OptionsVO> load() {
        return showroomTypeEntityRepository.findAll().stream().map(ShowroomTypeEntity::toVo).collect(Collectors.toList());
    }

    @Override
    public OptionsVO create(OptionsVO optionsVO) {
        ShowroomTypeEntity entity = new ShowroomTypeEntity();

        entity.setLabel(optionsVO.getLabel());
        entity.setValue(optionsVO.getValue());
        return showroomTypeEntityRepository.save(entity).toVo();
    }

}
