package com.kilpi.finayo.Repository;

import com.kilpi.finayo.Domain.BranchEntity;
import com.kilpi.finayo.Domain.DecentroTransactionEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface DecentroTransactionRepository extends JpaRepository<DecentroTransactionEntity, Integer> {

    @Query(value = "SELECT count(*) FROM decentro_transaction_table where type = ?1",nativeQuery = true)
    Integer findByType(String type);
}
