package com.kilpi.finayo.Repository;

import com.kilpi.finayo.Domain.BranchEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.awt.print.Pageable;
import java.util.Collection;
import java.util.List;

public interface BranchRepository extends JpaRepository<BranchEntity, Integer> {
//
//    @Query("SELECT b FROM BranchEntity b ORDER BY NEWID()")
//    Page<BranchEntity> findLast10(Pageable pageable );
}
