package com.kilpi.finayo.VO;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BranchVO {

    private Integer id;
    private String code;
    
    @NotNull
    @Size(min = 3, max = 25, message = "name must be of min 3 length")
    private String name;
    @NotNull
    @Pattern(regexp = "^([1-9]){9}[0-9]$", message = "number must be of length 10")
    private String mobile;
    @NotNull
    @Size(min = 5, max = 250, message = "address must be of min 5")
    private String address;
    @NotNull
    @Size(min=3, max = 25, message = "city must be between 3 and 25")
    private String city;
    @NotNull(message = "active can be either true or false ")
    private Boolean active;
    private OptionsVO businessType;
    private Integer executive;
}
