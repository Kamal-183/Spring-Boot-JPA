package com.kilpi.finayo.Domain;

import com.kilpi.finayo.VO.BranchDropdownVO;
import com.kilpi.finayo.VO.BranchVO;
import com.kilpi.finayo.VO.ExecutiveVO;
import lombok.Data;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Data
@Entity
@Table(name = "branch")
public class BranchEntity {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    Integer id;

    @Column(name = "code")
    String code;

    @Column(name = "first_name")
    String name;

    @Column(name = "mobile")
    String mobile;

    @Column(name = "address")
    String address;

    @Column(name = "city")
    String city;

    @OneToOne
    BusinessTypeEntity businessType;

    @Column(name = "active")
    Boolean active;

    @ManyToMany
    List<ShowroomTypeEntity> showroomTypes;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "branch_id")
    List<ExecutiveEntity> executiveEntities = new ArrayList<>();

    public BranchVO toVo() {
        return BranchVO.builder()
                .id(id)
                .name(name)
                .code(code)
                .mobile(mobile)
                .address(address)
                .city(city)
                .active(active)
               // .showroomTypes(showroomTypes == null?null:showroomTypes.stream().map(ShowroomTypeEntity::toVo).collect(Collectors.toList()))
                .businessType(businessType.toVo())
                .executive(executiveEntities == null ? 0:executiveEntities.size())
                .build();
    }

    public BranchDropdownVO toDropdownVo() {
        return BranchDropdownVO.builder()
                .id(id)
                .name(name)
                .build();
    }
}
