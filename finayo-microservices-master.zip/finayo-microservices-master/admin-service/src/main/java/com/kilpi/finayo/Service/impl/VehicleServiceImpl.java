package com.kilpi.finayo.Service.impl;

import com.kilpi.finayo.Service.VehicleService;
import org.springframework.stereotype.Service;

@Service
public class VehicleServiceImpl implements VehicleService {
}
