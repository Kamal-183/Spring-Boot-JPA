package com.kilpi.finayo.Service.impl;

import com.kilpi.finayo.Domain.BankEntity;
import com.kilpi.finayo.Domain.ExecutiveEntity;
import com.kilpi.finayo.Domain.UserEntity;
import com.kilpi.finayo.Repository.BankRepository;
import com.kilpi.finayo.Repository.ExecutiveRepository;
import com.kilpi.finayo.Repository.UserRepository;
import com.kilpi.finayo.Service.BranchService;
import com.kilpi.finayo.Service.UserService;
import com.kilpi.finayo.exception.NotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	ExecutiveRepository executiveRepository;

	@Autowired
    BankRepository bankRepository;

	@Autowired
	UserRepository userRepository;

	@Override
	public ExecutiveEntity getExecutive() {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		User map = (User) auth.getPrincipal();
		UserEntity user = userRepository.findByUsername(map.getUsername());
		Optional<ExecutiveEntity> executive = executiveRepository.findByCode(user.getUniqueId());
		if (!executive.isPresent()) {
			throw new NotFoundException("Unable to find executive details on above code " + user.getUniqueId());
		}
		return executive.get();
	}

	@Override
	public BankEntity getBankDetails() {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		User map = (User) auth.getPrincipal();
		UserEntity user = userRepository.findByUsername(map.getUsername());
		BankEntity bank = bankRepository.findByCode(user.getUniqueId());
		if (bank == null) {
			throw new NotFoundException("Unable to find Bank details on above code " + user.getUniqueId());
		}
		return bank;
	}

	@Override
	public BranchService getBranchDetails() {
		return null;
	}
}
