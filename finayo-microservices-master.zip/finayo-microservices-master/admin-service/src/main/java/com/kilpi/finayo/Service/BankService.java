package com.kilpi.finayo.Service;


import com.kilpi.finayo.VO.BankVO;
import com.kilpi.finayo.VO.ExecutiveVO;

import java.util.List;

public interface BankService {
    List<BankVO> load();

    BankVO create(BankVO bankVO);

    BankVO view(Integer id);

    BankVO update(Integer id, BankVO bankVO);

    List<BankVO> getBanksByCibil(Double score);
}
