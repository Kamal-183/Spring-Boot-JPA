package com.kilpi.finayo.Service.impl;

import com.kilpi.finayo.Constant.LoanStatus;
import com.kilpi.finayo.Domain.BranchEntity;
import com.kilpi.finayo.Domain.ExecutiveEntity;
import com.kilpi.finayo.Domain.Loan;
import com.kilpi.finayo.Domain.UserEntity;
import com.kilpi.finayo.Repository.*;
import com.kilpi.finayo.Service.ExecutiveService;
import com.kilpi.finayo.VO.BranchVO;
import com.kilpi.finayo.VO.ExecutiveVO;
import com.kilpi.finayo.VO.LoanVO;
import com.kilpi.finayo.VO.UserVO;
import com.kilpi.finayo.exception.NotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ExecutiveServiceImpl implements ExecutiveService {

    @Autowired
    private ExecutiveRepository executiveRepository;

    @Autowired
    private BranchRepository branchRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private LoanRepository loanRepository;

    @Autowired
    BankRepository bankRepository;

    @Override
    public List<ExecutiveVO> load(Integer limit) {
        List<ExecutiveVO> list =  executiveRepository.findAll().stream().map(ExecutiveEntity::toVo).collect(Collectors.toList());
        if(limit != null){
            Collections.shuffle(list);
            return list.subList(0, limit);
        }
        return list;
    }

    @Override
    public ExecutiveVO create(ExecutiveVO executiveVO) {

        Optional<BranchEntity> branch = branchRepository.findById(executiveVO.getBranch().getId());
        if(!branch.isPresent()){
            throw new NotFoundException("Invalid Branch selected");
        }
        String empId = "";
        ExecutiveEntity entity = new ExecutiveEntity();
        entity.setFirstName(executiveVO.getFirstName());
        entity.setLastName(executiveVO.getLastName());
        entity.setEmail(executiveVO.getEmail());
        entity.setMobile(executiveVO.getMobile());
        entity.setActive(Boolean.TRUE);
        entity.setAddress(executiveVO.getAddress());
        entity.setCity(executiveVO.getCity());
        entity.setBranch(branch.get());
        entity = executiveRepository.save(entity);

        String code = branch.get().getName().substring(0,2).toUpperCase();
        code += executiveVO.getFirstName().substring(0,2).toUpperCase();
        code += String.format("%04d", entity.getId());
        entity.setCode(code);

        this.createUser(entity);

        return executiveRepository.save(entity).toVo();
    }

    @Override
    public ExecutiveVO view(Integer id) {
        Optional<ExecutiveEntity> isExecutive = executiveRepository.findById(id);
        if(isExecutive.isPresent()) {
            return isExecutive.get().toVo();
        }
        return null;
    }

    @Override
    public ExecutiveVO update(Integer id, ExecutiveVO executiveVO) {

        Optional<ExecutiveEntity> isExecutive = executiveRepository.findById(id);
        if(isExecutive.isPresent()){
            ExecutiveEntity entity = isExecutive.get();
            entity.setFirstName(executiveVO.getFirstName());
            entity.setLastName(executiveVO.getLastName());
            entity.setEmail(executiveVO.getEmail());
            entity.setMobile(executiveVO.getMobile());
            entity.setActive(Boolean.TRUE);
            entity.setAddress(executiveVO.getAddress());
            entity.setCity(executiveVO.getCity());
            entity = executiveRepository.save(entity);

//            String code = branch.getName().substring(0,2).toUpperCase();
//            code += executiveVO.getFirstName().substring(0,2).toUpperCase();
//            code += String.format("%04d", entity.getId());
//            entity.setCode(code);

            return executiveRepository.save(entity).toVo();
        }
        return null;
    }

    @Override
    public List<LoanVO> getLoans(String code) {
        ExecutiveEntity executive = this.getExecutiveByCode(code);
        return loanRepository.findByExecutiveId(executive.getId()).stream().filter(loan -> loan.getBanks() != null ).map(Loan::toVo).collect(Collectors.toList()) ;
    }

    @Override
    public LoanVO updateLoan(Long loanId, String bCode) {
        Optional<Loan> isLoan = loanRepository.findById(loanId);
        if(isLoan.isPresent()){
            Loan loan = isLoan.get();
            loan.setBank(bankRepository.findByCode(bCode));
            loan.setLoanStatus(LoanStatus.APPLY);
            return loanRepository.save(loan).toVo();
        }

        return null;
    }

    private ExecutiveEntity getExecutiveByCode(String code){
        Optional<ExecutiveEntity> isExecutive = executiveRepository.findByCode(code);
        if(isExecutive.isPresent()){
            return isExecutive.get();
        }
        return null;
    }

    private void createUser(ExecutiveEntity entity) {


        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

        UserEntity newUser = new UserEntity();
        newUser.setFirstName(entity.getFirstName());
        newUser.setLastName(entity.getLastName());
        newUser.setUsername(entity.getEmail());
        newUser.setPassword(passwordEncoder.encode(entity.getCode()));
        newUser.setCity(entity.getCity());
        newUser.setAddress(entity.getAddress());
        newUser.setMobile(entity.getMobile());
        newUser.setRole("EXECUTIVE");
        newUser.setCompany(null);
        newUser.setActive(Boolean.TRUE);
        newUser.setUniqueId(entity.getCode());

         userRepository.save(newUser);
    }

	@Override
	public Integer ExecutiveCount() {
		return executiveRepository.findAll().size();
	}
}
