package com.kilpi.finayo.Repository;

import java.time.LocalDateTime;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.kilpi.finayo.Domain.Profile;
import org.springframework.stereotype.Repository;

@Repository
public interface ProfileRepository extends JpaRepository<Profile, Long> {
	
	List<Profile> findByExecutiveId(Integer executiveId);

	@Query(value="select  distinct  *\r\n"
			+ "from profile_details \r\n"
			+ "JOIN loan_details ON loan_details.profile_id =profile_details.pid\r\n"
			+ "where loan_details.status in (:status)"
			, nativeQuery=true)
	public List<Object[]> byStatus(@Param("status")List<String> statusList);
	
	@Modifying
	@Transactional
	@Query(value = "update loan_details set status = :status,updatedby= :updatedate where profile_id = :profileid", nativeQuery = true)
	void setLoanStatusById(@Param("status") String laonStatus,@Param("profileid") Long profileId,
			@Param("updatedate") LocalDateTime startDat);
	
	@Modifying
	@Transactional
	@Query(value = "update loan_details set status = :status,updatedby= :updatedate, complete_date= :updatedate where profile_id = :profileid", nativeQuery = true)
	void updateloanToCompleted(@Param("status") String laonStatus,@Param("profileid") Long profileId,
			@Param("updatedate") LocalDateTime startDat);

}
