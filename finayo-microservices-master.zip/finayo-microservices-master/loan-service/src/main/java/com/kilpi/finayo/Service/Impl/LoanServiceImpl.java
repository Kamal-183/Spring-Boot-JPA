package com.kilpi.finayo.Service.Impl;

import java.sql.Date;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kilpi.finayo.Constant.Constant;
import com.kilpi.finayo.Constant.LoanStatus;
import com.kilpi.finayo.Constant.ReportType;
import com.kilpi.finayo.Domain.BankEntity;
import com.kilpi.finayo.Domain.BankLoanEntity;
import com.kilpi.finayo.Domain.BranchEntity;
import com.kilpi.finayo.Domain.DSAEntity;
import com.kilpi.finayo.Domain.ExecutiveEntity;
import com.kilpi.finayo.Domain.Loan;
import com.kilpi.finayo.Domain.Profile;
import com.kilpi.finayo.Domain.UserEntity;
import com.kilpi.finayo.Mapper.DtoConverter;
import com.kilpi.finayo.Repository.BankRepository;
import com.kilpi.finayo.Repository.BranchRepository;
import com.kilpi.finayo.Repository.ExecutiveRepository;
import com.kilpi.finayo.Repository.LoanRepository;
import com.kilpi.finayo.Repository.ProfileRepository;
import com.kilpi.finayo.Service.LenderService;
import com.kilpi.finayo.Service.LoanService;
import com.kilpi.finayo.Service.UserService;
import com.kilpi.finayo.VO.BranchLoanCountVO;
import com.kilpi.finayo.VO.BranchLoanStatusVO;
import com.kilpi.finayo.VO.DailyDisburseVO;
import com.kilpi.finayo.VO.DashboardVO;
import com.kilpi.finayo.VO.ExcecutiveLoanCountVO;
import com.kilpi.finayo.VO.ExceutiveProfieVO;
import com.kilpi.finayo.VO.LoanCountVO;
import com.kilpi.finayo.VO.LoanProfilePage;
import com.kilpi.finayo.VO.LoanStatsVO;
import com.kilpi.finayo.VO.LoanStatusCount;
import com.kilpi.finayo.VO.LoanSummary;
import com.kilpi.finayo.VO.LoanVO;
import com.kilpi.finayo.VO.OveralDisburseVO;
import com.kilpi.finayo.VO.ProfileVO;
import com.kilpi.finayo.VO.ReportVO;
import com.kilpi.finayo.VO.ResultVO;
import com.kilpi.finayo.VO.ShowroomListVO;
import com.kilpi.finayo.VO.StatisticsVO;
import com.kilpi.finayo.VO.StatusVO;
import com.kilpi.finayo.exception.NotFoundException;

@Service
public class LoanServiceImpl implements LoanService {

	Logger logger = LoggerFactory.getLogger(LoanServiceImpl.class);

	@Autowired
	private ProfileRepository profileRepository;

	@Autowired
	BankRepository bankRepository;

	@Autowired
	private LoanRepository loanRepository;

	@Autowired
	private BranchRepository branchRepository;

	@Autowired
	private ExecutiveRepository executiveRepository;

	@Autowired
	private DtoConverter dtoConverter;

	@Autowired
	private UserService userService;

	@Autowired
	private LenderService lenderService;

	@Override
	public List<ProfileVO> getProfiles() {
		return profileRepository.findAll().stream().map(Profile::toVo).collect(Collectors.toList());
	}

	@Override
	public List<LoanVO> getLoans() {
		return loanRepository.findAll().stream().map(Loan::toVo).collect(Collectors.toList());
	}

	@Override
	public ProfileVO saveProfile(ProfileVO pProfileVO) {
		Profile profile = dtoConverter.profileVotoEntity(pProfileVO);
		return profileRepository.save(profile).toVo();
	}

	@Override
	@Transactional
	public LoanVO saveLoan(LoanVO pLoanVO) {
		ExecutiveEntity executive = userService.getExecutive();
		Loan loan = dtoConverter.loanVotoEntity(pLoanVO);
		loan.setCreatedBy(LocalDateTime.now());
		loan.setUpdatedby(LocalDateTime.now());
		loan.setAppDate(LocalDateTime.now());
		Profile profile = loan.getProfile();
		if (executive != null) {
			profile.setExecutiveId(executive.getId());
		}
		profileRepository.save(profile);
		return loanRepository.save(loan).toVo();
	}

	@Override
	public LoanStatsVO getLoanStastistitics() {
		LoanStatsVO loanStatsVO = null;
		loanStatsVO = new LoanStatsVO();
		loanStatsVO.setTotal(loanRepository.sumTotalLoan() == null ? 0 : loanRepository.sumTotalLoan());
		loanStatsVO.setDisburse(loanRepository.getSummaryByStatus(Constant.DISBURS) == null ? 0
				: loanRepository.getSummaryByStatus(Constant.DISBURS));
		loanStatsVO.setPending(loanRepository.getSummaryByStatus(Constant.HOLD) == null ? 0
				: loanRepository.getSummaryByStatus(Constant.HOLD));
		loanStatsVO.setReject(loanRepository.getSummaryByStatus(Constant.REJECT) == null ? 0
				: loanRepository.getSummaryByStatus(Constant.REJECT));
		return loanStatsVO;
	}

	public Long applyloanSummary() {
		return loanRepository.getSummaryByStatus(Constant.PENDING) == null ? 0
				: loanRepository.getSummaryByStatus(Constant.PENDING);
	}

	public Long approvedApplication() {
		return loanRepository.totalCountByStatus(Constant.DISBURS) == null ? 0
				: loanRepository.totalCountByStatus(Constant.DISBURS);
	}

	@Override
	public ReportVO loanReportByDays(ReportType pReportType) {
		ReportVO reportVO = new ReportVO();
		if (pReportType.equals(ReportType.DAILY)) {
			reportVO.setError(""); // TODO: Need to implemeted
			reportVO.setType(ReportType.DAILY.toString());
			ResultVO resultVO = gettingWeeklyReport();
			reportVO.setResultVO(resultVO);
		}
		if (pReportType.equals(ReportType.WEEKLY)) {
			reportVO.setError(""); // TODO: Need to implemeted
			reportVO.setType(ReportType.WEEKLY.toString());
			ResultVO resultVO = gettingMonthlyReport();
			reportVO.setResultVO(resultVO);
		}
		if (pReportType.equals(ReportType.MONTHLY)) {
			reportVO.setError(""); // TODO: Need to implemeted
			reportVO.setType(ReportType.MONTHLY.toString());
			ResultVO resultVO = gettingYearlyReport();
			reportVO.setResultVO(resultVO);
		}

		return reportVO;
	}

	private ResultVO gettingWeeklyReport() {

		ResultVO resultVO = new ResultVO();

		LocalDate startDate = LocalDate.now().minusDays(6);
		LocalDate lastData = LocalDate.now();
		Integer day = 1;

		List<Object> days = new ArrayList<>();
		while (day <= 7) {

			Map<String, List<Object>> mon = new HashMap<>();
			List<Object> data = new ArrayList<>();
			data.add(startDate.getDayOfWeek().toString().substring(0, 3));
			data.addAll(extracted(startDate.atTime(LocalTime.MIN), startDate.atTime(LocalTime.MAX)));

			days.add(data);

			startDate = startDate.plusDays(1);
			day++;

		}
		resultVO.setDays(days);
		return resultVO;
	}

	private ResultVO gettingMonthlyReport() {
		ResultVO resultVO = new ResultVO();

		LocalDate startDate = LocalDate.now().minusWeeks(5).with(DayOfWeek.SUNDAY);
		LocalDate lastData = LocalDate.now();
		Integer week = 1;

		List<Object> weeks = new ArrayList<>();
		while (week <= 5) {
			LocalDate endDate = startDate.plusWeeks(1).minusDays(1);

			Map<String, List<Object>> mon = new HashMap<>();
			List<Object> data = new ArrayList<>();
			data.add(startDate.getDayOfMonth() + "/" + startDate.getMonthValue() + " - " + endDate.getDayOfMonth() + "/"
					+ endDate.getMonthValue());
			data.addAll(extracted(startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX)));
			weeks.add(data);

			startDate = startDate.plusWeeks(1);
			if (startDate.isAfter(lastData)) {
				startDate = lastData;
			}
			week++;

		}
		resultVO.setWeeks(weeks);
		return resultVO;

	}

	private ResultVO gettingYearlyReport() {

		ResultVO resultVO = new ResultVO();

		LocalDate startDate = LocalDate.now().minusMonths(5).withDayOfMonth(1);
		LocalDate lastData = LocalDate.now();
		Integer month = startDate.getMonthValue();
		List<Object> months = new ArrayList<>();
		do {

			month = startDate.getMonthValue();
			LocalDate endDate = startDate.plusDays(startDate.lengthOfMonth() - 1);

			Map<String, List<Object>> mon = new HashMap<>();
			List<Object> data = new ArrayList<>();
			data.add(startDate.getMonth().toString().substring(0, 3));
			data.addAll(extracted(startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX)));

			months.add(data);

			startDate = startDate.plusMonths(1);

			if(startDate.isAfter(lastData)){
				startDate = lastData;
			}

		} while (month != lastData.getMonthValue());
		resultVO.setMonths(months);
		return resultVO;
	}

	private List<Object> extracted(LocalDateTime startDate, LocalDateTime endDate) {
		List<Object> day1 = new ArrayList<Object>();
		day1.add(loanRepository.getLoanReportByStatusDate(startDate, endDate, Constant.NEW));
		day1.add(loanRepository.getLoanReportByStatusDate(startDate, endDate, Constant.APPLY));
		day1.add(loanRepository.getLoanReportByStatusDate(startDate, endDate, Constant.INPROGRESS));
		day1.add(loanRepository.getLoanReportByStatusDate(startDate, endDate, Constant.REJECT));
		day1.add(loanRepository.getLoanReportByStatusDate(startDate, endDate, Constant.COMPLETED));
		return day1;
	}

	@Override
	public BranchLoanStatusVO loanStatusForBranch(LoanStatus loanStatus, String pCatagory) {
		BranchLoanStatusVO branchLoanStatusVO = new BranchLoanStatusVO();
		branchLoanStatusVO.setError("");
		branchLoanStatusVO.setType(loanStatus.toString().toLowerCase());
		branchLoanStatusVO.setCategory(pCatagory);
		List<Object[]> objects = new ArrayList<Object[]>();
		if (pCatagory.equalsIgnoreCase("all")) {
			objects = loanRepository.getStatusByBranch(loanStatus.toString());
		} else if (pCatagory.equalsIgnoreCase("daily")) {
			objects = loanRepository.getDailyStatusByBranch(loanStatus.toString(), LocalDate.now().atTime(0, 0, 0),
					LocalDate.now().plusDays(1).atTime(0, 0, 0));
		}
		List<BranchLoanCountVO> branchLoanCountList = new ArrayList<BranchLoanCountVO>();
		for (Object[] object : objects) {
			if (object != null) {
				BranchLoanCountVO branchLoanCountVO = new BranchLoanCountVO();
				branchLoanCountVO.setCnt(Integer.valueOf(object[0].toString()));
				branchLoanCountVO.setName(object[1].toString());
				branchLoanCountList.add(branchLoanCountVO);
			}
		}
		/*
		 * //TODO for Empty data if (objects != null & objects.isEmpty()) {
		 * BranchLoanCountVO branchLoanCountVO = new BranchLoanCountVO();
		 * branchLoanCountVO.setCnt(0); branchLoanCountVO.setName("");
		 * branchLoanCountList.add(branchLoanCountVO); }
		 */
		branchLoanStatusVO.setResult(branchLoanCountList);
		return branchLoanStatusVO;
	}

	@Override
	public ExcecutiveLoanCountVO loanStatuByExecutive(String executiveName, Integer executiveId) {
		ExcecutiveLoanCountVO excecutiveLoanCountVO = new ExcecutiveLoanCountVO();
		excecutiveLoanCountVO.setError("");
		excecutiveLoanCountVO.setType("year");
		List<LoanCountVO> loanCountVOList = new ArrayList<LoanCountVO>();
		List<Object[]> objects = new ArrayList<Object[]>();
		if (executiveName != null) {
			objects = loanRepository.getCountByExecutiveName(executiveName);
		} else if (executiveId != null) {
			objects = loanRepository.getCountByExecutiveId(executiveId);
		} else {
			objects = loanRepository.getCountAllExecutive();
		}
		for (Object[] object : objects) {
			if (object != null) {
				LoanCountVO loanCountVO = new LoanCountVO();
				List<String> titleList = new ArrayList<>();
				titleList.add("Task");
				titleList.add("Hours per Day");
				loanCountVO.setTitle(titleList);

				List<Object> applied = new ArrayList<>();
				applied.add("Applied");
				applied.add(object[0] != null ? Integer.valueOf(object[0].toString()) : 0);
				loanCountVO.setApplied(applied);

				List<Object> pending = new ArrayList<>();
				pending.add("Pending");
				pending.add(object[1] != null ? Integer.valueOf(object[1].toString()) : 0);
				loanCountVO.setPending(pending);

				List<Object> rejected = new ArrayList<>();
				rejected.add("Reject");
				rejected.add(object[2] != null ? Integer.valueOf(object[2].toString()) : 0);
				loanCountVO.setReject(rejected);

				List<Object> dishburshed = new ArrayList<>();
				dishburshed.add("Disburse");
				dishburshed.add(object[3] != null ? Integer.valueOf(object[3].toString()) : 0);
				loanCountVO.setDisburse(dishburshed);

				loanCountVOList.add(loanCountVO);
			}
		}
		if (objects != null & objects.isEmpty()) {
			LoanCountVO loanCountVO = new LoanCountVO();
			List<String> titleList = new ArrayList<>();
			titleList.add("Task");
			titleList.add("Hours per Day");
			loanCountVO.setTitle(titleList);
			List<Object> applied = new ArrayList<>();
			applied.add("Applied");
			applied.add(0);
			loanCountVO.setApplied(applied);
			List<Object> pending = new ArrayList<>();
			pending.add("Pending");
			pending.add(0);
			loanCountVO.setPending(pending);
			List<Object> rejected = new ArrayList<>();
			rejected.add("Reject");
			rejected.add(0);
			loanCountVO.setReject(rejected);
			List<Object> disburse = new ArrayList<>();
			disburse.add("Disburse");
			disburse.add(0);
			loanCountVO.setDisburse(disburse);
			loanCountVOList.add(loanCountVO);
		}
		excecutiveLoanCountVO.setResult(loanCountVOList);
		return excecutiveLoanCountVO;
	}

	@Override
	public DashboardVO displayDashboard() {
		DashboardVO dashboardVO = new DashboardVO();
		StatisticsVO statisticsVO = new StatisticsVO();
		LoanStatsVO lLoanStatsVO = getLoanStastistitics();
		statisticsVO.setTotal(lLoanStatsVO.getTotal());
		statisticsVO.setPending(lLoanStatsVO.getPending());
		statisticsVO.setReject(lLoanStatsVO.getReject());
		statisticsVO.setDisbursed(lLoanStatsVO.getDisburse());
		dashboardVO.setStatistics(statisticsVO);
		ResultVO resultVO = gettingWeeklyReport();
		dashboardVO.setBarWeeklyVO(resultVO.getDays());

		LoanStatus loanStatus = LoanStatus.DISBURS;
		List<BranchLoanCountVO> branchLoanCountList = loanStatusForBranch(loanStatus, "daily").getResult();
		List<DailyDisburseVO> dailyDishburshedVO = new ArrayList();
		for (BranchLoanCountVO branchLoanCountVO : branchLoanCountList) {
			DailyDisburseVO dailyDishburshed = new DailyDisburseVO();
			dailyDishburshed.setName(branchLoanCountVO.getName());
			dailyDishburshed.setCnt(branchLoanCountVO.getCnt());
			dailyDishburshedVO.add(dailyDishburshed);
		}
		dashboardVO.setDailyDisburse(dailyDishburshedVO);

		List<BranchLoanCountVO> allLoanCountList = loanStatusForBranch(loanStatus, "all").getResult();
		List<OveralDisburseVO> overalDishburshedVO = new ArrayList<OveralDisburseVO>();
		for (BranchLoanCountVO branchLoanCountVO : allLoanCountList) {
			OveralDisburseVO overalDishburshed = new OveralDisburseVO();
			overalDishburshed.setName(branchLoanCountVO.getName());
			overalDishburshed.setCnt(branchLoanCountVO.getCnt());
			overalDishburshedVO.add(overalDishburshed);
		}
		dashboardVO.setOveralDisburse(overalDishburshedVO);

		List<ShowroomListVO> showroomListVO = new ArrayList<ShowroomListVO>(); // TODO
		ShowroomListVO showroom = new ShowroomListVO();
		showroom.setName("Dummy ShowRoom");
		showroom.setEmail("dummy@gmail.com");
		showroom.setEmployee(23);
		showroom.setPhone("+918790320821");
		showroom.setAddress("K Road,Pune");
		showroomListVO.add(showroom);
		ShowroomListVO showroom2 = new ShowroomListVO();
		showroom.setName("Dummy ShowRoom2");
		showroom.setEmail("dummy2@gmail.com");
		showroom.setEmployee(21);
		showroom.setPhone("+917777320821");
		showroom.setAddress("p Road,Pune");
		showroomListVO.add(showroom2);
		dashboardVO.setShowroomListVO(showroomListVO);

		return dashboardVO;
	}

	@Override
	public List<ProfileVO> profileListByExecutiveStatus(LoanStatus loanStatus) {
		ExecutiveEntity exe = userService.getExecutive();

		List<ProfileVO> profileVOs = new ArrayList<ProfileVO>();
		List<Object[]> objects = new ArrayList<Object[]>();
		if (loanStatus == null) {
			List<Loan> loans = loanRepository.findByExecutiveId(exe.getId());
			for (Loan loan : loans) {
				loan.setBanks(loan.getBanks().stream().sorted().collect(Collectors.toList()));
				ProfileVO profileVO = loan.getProfile().toVo();
				profileVO.setLoanVO(loan.toVo());
				profileVOs.add(profileVO);
			}

		} else {
			List<Loan> loans = loanRepository.findByExecutiveIdAndStatus(exe.getId(), loanStatus);
			for (Loan loan : loans) {
				ProfileVO profileVO = loan.getProfile().toVo();
				profileVO.setLoanVO(loan.toVo());
				profileVOs.add(profileVO);
			}
		}

		return profileVOs;
	}

	@Override
	public List<ProfileVO> profileListByExecutiveStatus(LoanStatus loanStatus, Integer executiveId) {

		ExecutiveEntity executive;
		if(executiveId != null) {
			executive = executiveRepository.findById(executiveId).get();
		} else {
			executive = userService.getExecutive();
		}

		List<ProfileVO> profileVOs = new ArrayList<ProfileVO>();
		List<Object[]> objects = new ArrayList<Object[]>();
		if (loanStatus == null) {
			List<Loan> loans = loanRepository.findByExecutiveId(executiveId);
			for (Loan loan : loans) {
				ProfileVO profileVO = loan.getProfile().toVo();
				profileVO.setLoanVO(loan.toVo());
				profileVOs.add(profileVO);
			}

		} else {
			List<Loan> loans = loanRepository.findByExecutiveIdAndStatus(executiveId, loanStatus);
			for (Loan loan : loans) {
				ProfileVO profileVO = loan.getProfile().toVo();
				profileVO.setLoanVO(loan.toVo());
				profileVOs.add(profileVO);
			}
		}

		return profileVOs;
	}

	@Override
	public long countLoanByBranchName(String brachName, LoanStatus pStatus) {
		List<Object[]> objects = new ArrayList<Object[]>();
		long summary = 0;
		if (pStatus.equals(LoanStatus.INPROGRESS)) {
			objects = loanRepository.getCountByBranch(brachName, Constant.NOT_DISBURSH);
			for (Object[] object : objects) {
				if (object != null) {
					summary = Long.valueOf(object[0].toString());
				}
			}
		} else if (pStatus.equals(LoanStatus.DISBURS)) {
			objects = loanRepository.getCountByBranch(brachName, Arrays.asList(LoanStatus.DISBURS.toString()));
			for (Object[] object : objects) {
				if (object != null) {
					summary = Long.valueOf(object[0].toString());
				}
			}
		}
		return summary;
	}

	@Override
	public long countLoanByBranchId(Integer id, LoanStatus pStatus) {
		List<Object[]> objects = new ArrayList<Object[]>();
		long summary = 0;
		if (pStatus.equals(LoanStatus.INPROGRESS)) {
			objects = loanRepository.getCountByBranchId(id, Constant.NOT_DISBURSH);
			for (Object[] object : objects) {
				if (object != null) {
					summary = Long.valueOf(object[0].toString());
				}
			}
		} else if (pStatus.equals(LoanStatus.DISBURS)) {
			objects = loanRepository.getCountByBranchId(id, Arrays.asList(LoanStatus.DISBURS.toString()));
			for (Object[] object : objects) {
				if (object != null) {
					summary = Long.valueOf(object[0].toString());
				}
			}
		}
		return summary;
	}

	@Override
	public ExceutiveProfieVO getExceutiveProfieVO(Integer pExceutiveId) {
		ExceutiveProfieVO exceutiveProfieVO = null;
		Optional<ExecutiveEntity> executive = executiveRepository.findById(pExceutiveId);
		if (executive.get() != null) {
			exceutiveProfieVO = new ExceutiveProfieVO();
			exceutiveProfieVO.setName(executive.get().getFirstName() + " " + executive.get().getLastName());
			exceutiveProfieVO.setMail(executive.get().getEmail());
			exceutiveProfieVO.setPhone(executive.get().getMobile());
			exceutiveProfieVO.setBranchName(executive.get().getBranch().getName());
			exceutiveProfieVO.setShowroomName(executive.get().getBranch().getName());
			exceutiveProfieVO.setBranchAddress(executive.get().getBranch().getAddress());
			exceutiveProfieVO.setBranchId(executive.get().getBranch().getCode());
		}
		return exceutiveProfieVO;
	}

	@Override
	public ExceutiveProfieVO getBranchProfieVO(Integer pExceutiveId) {
		ExceutiveProfieVO exceutiveProfieVO = null;
		Optional<BranchEntity> executive = branchRepository.findById(pExceutiveId);
		if (executive.get() != null) {
			exceutiveProfieVO = new ExceutiveProfieVO();
			exceutiveProfieVO.setBranchName(executive.get().getName());
			exceutiveProfieVO.setShowroomName(executive.get().getName());
			exceutiveProfieVO.setBranchAddress(executive.get().getAddress());
			exceutiveProfieVO.setBranchId(executive.get().getCode());
			exceutiveProfieVO.setBranchCity(executive.get().getCity());
			exceutiveProfieVO.setBranchContact(executive.get().getMobile());
		}
		return exceutiveProfieVO;
	}

	@Override
	public List<ProfileVO> getProfileByBranch(Integer pBranchId, LoanStatus loanStatus) {
		List<ProfileVO> profileVOs = new ArrayList<ProfileVO>();
		List<ExecutiveEntity> listExecutivs = new ArrayList<>();
		Optional<BranchEntity> branch = branchRepository.findById(pBranchId);
		List<Object[]> objects = new ArrayList<Object[]>();
		if (branch.get() != null) {
			listExecutivs = executiveRepository.findByBranch(branch.get());
		}
		for (ExecutiveEntity executiveEntity : listExecutivs) {
			if (loanStatus == null) {

				List<Loan> loans = loanRepository.findByExecutiveId(executiveEntity.getId());
				for (Loan loan : loans) {
					ProfileVO profileVO = loan.getProfile().toVo();
					profileVO.setLoanVO(loan.toVo());
					profileVOs.add(profileVO);
				}
			} else {
				List<Loan> loans = loanRepository.findByExecutiveIdAndStatus(executiveEntity.getId(), loanStatus);
				for (Loan loan : loans) {
					ProfileVO profileVO = loan.getProfile().toVo();
					profileVO.setLoanVO(loan.toVo());
					profileVOs.add(profileVO);
				}
			}
		}
		return profileVOs;
	}

	@Override
	public LoanProfilePage loanProfilePage() {
		LoanProfilePage loanProfilePage = new LoanProfilePage();
		List<ProfileVO> profileVOs = new ArrayList<>();
		for (ProfileVO profileVO : getProfiles()) {
			Loan loan = loanRepository.findByProfile(profileRepository.findById(profileVO.getProfileId()).get());
			loan.setProfile(null);
			profileVO.setLoanVO(loan.toVo());
			profileVOs.add(profileVO);
		}
		loanProfilePage.setProfileVOs(profileVOs);
		LoanSummary loanSummary = new LoanSummary();
		loanSummary.setTotalLoanAmount(loanRepository.sumTotalLoan() == null ? 0 : loanRepository.sumTotalLoan());
		ExcecutiveLoanCountVO excecutiveLoanCountVO = loanStatuByExecutive(null, null);
		List<LoanCountVO> countVOs = excecutiveLoanCountVO.getResult();
		long loansummary = 0;
		for (LoanCountVO loanCountVO : countVOs) {
			loansummary = loansummary + Long.valueOf(loanCountVO.reject.get(1).toString());
			loansummary = loansummary + Long.valueOf(loanCountVO.pending.get(1).toString());
		}
		loanSummary.setApproved(loansummary);
		ArrayList<String> loanStatus = new ArrayList<String>();
		loanStatus.add(LoanStatus.DISBURS.toString());
		List<LoanVO> profileList = lenderService.getLoans();
		loanSummary.setTotalBorrower((long) profileList.size());
		loanProfilePage.setLoanSummary(loanSummary);
		return loanProfilePage;
	}

	@Override
	public LoanProfilePage executiveProfilePage(Integer pExceutiveId) {
		ExecutiveEntity executive;
		if(pExceutiveId != null) {
			executive = executiveRepository.findById(pExceutiveId).get();
		} else {
			executive = userService.getExecutive();
		}

		pExceutiveId = executive.getId();
		LoanProfilePage loanProfilePage = new LoanProfilePage();
		List<ProfileVO> profileVOs = new ArrayList<>();
		List<ProfileVO> profiles = profileRepository.findByExecutiveId(pExceutiveId).stream().map(Profile::toVo)
				.collect(Collectors.toList());
		for (ProfileVO profileVO : profiles) {
			Loan loan = loanRepository.findByProfile(profileRepository.findById(profileVO.getProfileId()).get());
			loan.setProfile(null);
			profileVO.setLoanVO(loan.toVo());
			profileVOs.add(profileVO);
		}
		loanProfilePage.setProfileVOs(profileVOs);
		LoanSummary loanSummary = new LoanSummary();
		ExcecutiveLoanCountVO excecutiveLoanCountVO = loanStatuByExecutive(null, pExceutiveId);
		List<LoanCountVO> countVOs = excecutiveLoanCountVO.getResult();
		long loansummary = 0;
		for (LoanCountVO loanCountVO : countVOs) {
			loansummary = loansummary + Long.valueOf(loanCountVO.applied.get(1).toString());
			loansummary = loansummary + Long.valueOf(loanCountVO.reject.get(1).toString());
			loansummary = loansummary + Long.valueOf(loanCountVO.pending.get(1).toString());
		}
		loanSummary.setApproved(loansummary);
		long disburshsummary = 0;
		for (LoanCountVO loanCountVO : countVOs) {
			disburshsummary = disburshsummary + Long.valueOf(loanCountVO.disburse.get(1).toString());
		}
		loanSummary.setTotalBorrower(disburshsummary);
		loanProfilePage.setLoanSummary(loanSummary);
		ExceutiveProfieVO exceutiveProfieVO = getExceutiveProfieVO(pExceutiveId);
		loanProfilePage.setExceutiveProfieVO(exceutiveProfieVO);
		return loanProfilePage;
	}

	@Override
	public LoanProfilePage branchProfilePage(Integer pBranchId) {
		LoanProfilePage loanProfilePage = new LoanProfilePage();
		ExceutiveProfieVO exceutiveProfieVO = getBranchProfieVO(pBranchId);
		loanProfilePage.setExceutiveProfieVO(exceutiveProfieVO);

		List<ProfileVO> profileList =getProfileByBranch(pBranchId,null);
		loanProfilePage.setProfileVOs(profileList);
		LoanSummary loanSummary = new LoanSummary();
		loanSummary.setApproved(countLoanByBranchId(pBranchId, LoanStatus.INPROGRESS));
		loanSummary.setTotalBorrower(countLoanByBranchId(pBranchId, LoanStatus.DISBURS));
		loanProfilePage.setLoanSummary(loanSummary);
		return loanProfilePage;
	}

	@Override
	public ProfileVO updateLoanStatus(StatusVO statusVo) {

		Loan loan = loanRepository.findByProfile(profileRepository.findById(statusVo.getId()).get());
		if (loan == null) {
			throw new NotFoundException("Invalid Loan");
		}

		if (statusVo.getStatus().equalsIgnoreCase(LoanStatus.APPROVE.toString())
				|| statusVo.getStatus().equalsIgnoreCase(LoanStatus.REJECT.toString())) {
			BankEntity bank = userService.getBankDetails();
			if (bank != null) {
				List<BankLoanEntity> loans = new ArrayList<>();
//					loans.addAll(loan.getBanks());
				Optional<BankLoanEntity> isBankLoan = loan.getBanks().stream()
						.filter(bl -> bl.getBank().getId() == bank.getId()).findFirst();
				BankLoanEntity bankLoan;
				if (isBankLoan.isPresent()) {

					bankLoan = isBankLoan.get();
				} else {
					bankLoan = new BankLoanEntity();
				}
				bankLoan.setLoan(loan);
				bankLoan.setBank(bank);
				bankLoan.setStatus(statusVo.getStatus());
				bankLoan.setInterest(null);
				bankLoan.setReason(statusVo.getReason());
				loans.add(bankLoan);
				bank.setLoans(loans);
				bankRepository.save(bank);
			}
		} else {

			for (BankLoanEntity bankLoan : loan.getBanks()) {
				if (loan.getBank().getId() == bankLoan.getBank().getId())
					bankLoan.setStatus(statusVo.getStatus().toUpperCase());
			}
			loan.setLoanStatus(LoanStatus.fromString(statusVo.getStatus()).get());
			loan.setUpdatedby(LocalDateTime.now());
			if (statusVo.getStatus().toUpperCase().equals(LoanStatus.DISBURS.toString())) {
				loan.setCompleteDate(LocalDateTime.now());
			}
			loanRepository.save(loan);
		}
		ProfileVO rProfileVO = null;
		rProfileVO = loan.getProfile().toVo();
		rProfileVO.setLoanVO(loan.toVo());
		return rProfileVO;
	}

	public LoanProfilePage loanDailyStatus(Integer pExecutiveId, LocalDateTime startDate, LocalDateTime endDate) {
		LoanProfilePage loanProfilePage = new LoanProfilePage();
		List<Object[]> objects = new ArrayList<Object[]>();
		if (pExecutiveId == null) {
			objects = loanRepository.getCountByDate(startDate, endDate);
		} else {
			objects = loanRepository.getCountByExecutiveDate(pExecutiveId, startDate, endDate);
		}

		LoanSummary loanSummary = new LoanSummary();
		long approved = 0;
		long disbush = 0;
		for (Object[] object : objects) {
			if (object != null) {
				approved = (object[0] != null ? Integer.valueOf(object[0].toString()) : 0)
						+ (object[1] != null ? Integer.valueOf(object[1].toString()) : 0)
						+ (object[2] != null ? Integer.valueOf(object[2].toString()) : 0);
				disbush = object[3] != null ? Integer.valueOf(object[3].toString()) : 0;
			}
		}
		loanSummary.setApproved(approved);
		loanSummary.setTotalBorrower(disbush);
		loanSummary.setTotalLoanAmount(null);
		loanProfilePage.setLoanSummary(loanSummary);
		return loanProfilePage;
	}

	@Override
	public LoanProfilePage executiveDailyStatusReport(Integer pExecutiveId, LocalDateTime startDate,
			LocalDateTime endDate) {
		LoanProfilePage loanProfilePage = new LoanProfilePage();
		List<Object[]> objects = loanRepository.getCountByExecutiveDate(pExecutiveId, startDate, endDate);
		LoanStatusCount loanStatusCount = new LoanStatusCount();
		long apply = 0;
		long inprogress = 0;
		long hold = 0;
		long reject = 0;
		long disbush = 0;
		long approve = 0;
		for (Object[] object : objects) {
			if (object != null) {
				apply = object[0] != null ? Integer.valueOf(object[0].toString()) : 0;
				hold = object[1] != null ? Integer.valueOf(object[1].toString()) : 0;
				reject = object[2] != null ? Integer.valueOf(object[2].toString()) : 0;
				disbush = object[3] != null ? Integer.valueOf(object[3].toString()) : 0;
				inprogress = object[4] != null ? Integer.valueOf(object[4].toString()) : 0;
				approve = object[5] != null ? Integer.valueOf(object[5].toString()) : 0;
			}
		}
		loanStatusCount.setApply(apply);
		loanStatusCount.setInprogress(inprogress);
		loanStatusCount.setHold(hold);
		loanStatusCount.setReject(reject);
		loanStatusCount.setApprove(approve);
		loanStatusCount.setDisburse(disbush);
		loanProfilePage.setLoanStatusCount(loanStatusCount);
		return loanProfilePage;
	}

	@Override
	public LoanProfilePage branchDailyStatusReport(Integer pBranchId, LocalDateTime startDate, LocalDateTime endDate) {
		LoanProfilePage loanProfilePage = new LoanProfilePage();
		List<Object[]> objects = loanRepository.getCountByBranchDate(pBranchId, startDate, endDate);
		LoanStatusCount loanStatusCount = new LoanStatusCount();
		long apply = 0;
		long inprogress = 0;
		long hold = 0;
		long reject = 0;
		long disbush = 0;
		long approve = 0;
		for (Object[] object : objects) {
			if (object != null) {
				apply = object[0] != null ? Integer.valueOf(object[0].toString()) : 0;
				hold = object[1] != null ? Integer.valueOf(object[1].toString()) : 0;
				reject = object[2] != null ? Integer.valueOf(object[2].toString()) : 0;
				disbush = object[3] != null ? Integer.valueOf(object[3].toString()) : 0;
				inprogress = object[4] != null ? Integer.valueOf(object[4].toString()) : 0;
				approve = object[5] != null ? Integer.valueOf(object[5].toString()) : 0;
			}
		}
		loanStatusCount.setApply(apply);
		loanStatusCount.setInprogress(inprogress);
		loanStatusCount.setHold(hold);
		loanStatusCount.setReject(reject);
		loanStatusCount.setApprove(approve);
		loanStatusCount.setDisburse(disbush);
		loanProfilePage.setLoanStatusCount(loanStatusCount);
		return loanProfilePage;
	}

	private List<Object> extractedByExecutive(LocalDateTime startDate, LocalDateTime endDate) {
		List<Object> day1 = new ArrayList<Object>();
		ExecutiveEntity executive = userService.getExecutive();
		day1.add(loanRepository.getLoanReportByStatusDateAndExecutive(startDate, endDate, Constant.NEW,
				executive.getId()));
		day1.add(loanRepository.getLoanReportByStatusDateAndExecutive(startDate, endDate, Constant.APPLY,
				executive.getId()));
		day1.add(loanRepository.getLoanReportByStatusDateAndExecutive(startDate, endDate, Constant.INPROGRESS,
				executive.getId()));
		day1.add(loanRepository.getLoanReportByStatusDateAndExecutive(startDate, endDate, Constant.REJECT,
				executive.getId()));
		day1.add(loanRepository.getLoanReportByStatusDateAndExecutive(startDate, endDate, Constant.DISBURS,
				executive.getId()));
		return day1;
	}

	private ResultVO gettingWeeklyReportExecutive() {

		ResultVO resultVO = new ResultVO();
		LocalDate startDate = LocalDate.now().minusDays(6);
		LocalDate lastData = LocalDate.now();
		Integer day = 1;

		List<Object> days = new ArrayList<>();
		while (day <= 7) {

			Map<String, List<Object>> mon = new HashMap<>();
			List<Object> data = new ArrayList<>();
			data.add(startDate.getDayOfWeek().toString().substring(0, 3));
			data.addAll(extractedByExecutive(startDate.atTime(LocalTime.MIN), startDate.atTime(LocalTime.MAX)));

			days.add(data);

			startDate = startDate.plusDays(1);
			day++;

		}
		resultVO.setDays(days);
		return resultVO;
	}

	private ResultVO gettingMonthlyReportExecutive() {
		ResultVO resultVO = new ResultVO();

		LocalDate startDate = LocalDate.now().minusWeeks(5).with(DayOfWeek.SUNDAY);
		LocalDate lastData = LocalDate.now();
		Integer week = 1;

		List<Object> weeks = new ArrayList<>();
		while (week <= 5) {
			LocalDate endDate = startDate.plusWeeks(1).minusDays(1);

			Map<String, List<Object>> mon = new HashMap<>();
			List<Object> data = new ArrayList<>();
			data.add(startDate.getDayOfMonth() + "/" + startDate.getMonthValue() + " - " + endDate.getDayOfMonth() + "/"
					+ endDate.getMonthValue());
			data.addAll(extractedByExecutive(startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX)));
			weeks.add(data);

			startDate = startDate.plusWeeks(1);
			if (startDate.isAfter(lastData)) {
				startDate = lastData;
			}
			week++;

		}
		resultVO.setWeeks(weeks);
		return resultVO;

	}

	private ResultVO gettingYearlyReportExecutive() {

		ResultVO resultVO = new ResultVO();

		LocalDate startDate = LocalDate.now().minusMonths(5).withDayOfMonth(1);
		LocalDate lastData = LocalDate.now();
		Integer month = startDate.getMonthValue();
		List<Object> months = new ArrayList<>();
		do {

			month = startDate.getMonthValue();
			LocalDate endDate = startDate.plusDays(startDate.lengthOfMonth() - 1);

			Map<String, List<Object>> mon = new HashMap<>();
			List<Object> data = new ArrayList<>();
			data.add(startDate.getMonth().toString().substring(0, 3));
			data.addAll(extractedByExecutive(startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX)));

			months.add(data);

			startDate = startDate.plusMonths(1);
			if (startDate.isAfter(lastData)) {
				startDate = lastData;
			}

		} while (month != lastData.getMonthValue());
		resultVO.setMonths(months);
		return resultVO;
	}

	private ReportVO loanReportByDaysExecutive(ReportType pReportType) {
		ReportVO reportVO = new ReportVO();
		if (pReportType.equals(ReportType.DAILY)) {
			reportVO.setError(""); // TODO: Need to implemeted
			reportVO.setType(ReportType.DAILY.toString());
			ResultVO resultVO = gettingWeeklyReportExecutive();
			reportVO.setResultVO(resultVO);
		}
		if (pReportType.equals(ReportType.WEEKLY)) {
			reportVO.setError(""); // TODO: Need to implemeted
			reportVO.setType(ReportType.WEEKLY.toString());
			ResultVO resultVO = gettingMonthlyReportExecutive();
			reportVO.setResultVO(resultVO);
		}
		if (pReportType.equals(ReportType.MONTHLY)) {
			reportVO.setError(""); // TODO: Need to implemeted
			reportVO.setType(ReportType.MONTHLY.toString());
			ResultVO resultVO = gettingYearlyReportExecutive();
			reportVO.setResultVO(resultVO);
		}

		return reportVO;
	}

	private ReportVO loanReportByDaysLender(ReportType pReportType) {
		ReportVO reportVO = new ReportVO();
		if (pReportType.equals(ReportType.DAILY)) {
			reportVO.setError(""); // TODO: Need to implemeted
			reportVO.setType(ReportType.DAILY.toString());
			ResultVO resultVO = gettingWeeklyReportLender();
			reportVO.setResultVO(resultVO);
		}
		if (pReportType.equals(ReportType.WEEKLY)) {
			reportVO.setError(""); // TODO: Need to implemeted
			reportVO.setType(ReportType.WEEKLY.toString());
			ResultVO resultVO = gettingMonthlyReportLender();
			reportVO.setResultVO(resultVO);
		}
		if (pReportType.equals(ReportType.MONTHLY)) {
			reportVO.setError(""); // TODO: Need to implemeted
			reportVO.setType(ReportType.MONTHLY.toString());
			ResultVO resultVO = gettingYearlyReportLender();
			reportVO.setResultVO(resultVO);
		}

		return reportVO;
	}

	private List<Object> extractedByLender(LocalDateTime startDate, LocalDateTime endDate) {
		List<Object> day1 = new ArrayList<Object>();
		BankEntity bank = userService.getBankDetails();
		day1.add(loanRepository.getLoanReportByStatusDateNew(startDate, endDate, Constant.NEW));
		day1.add(loanRepository.getLoanReportByStatusDateAndBank(startDate, endDate, Constant.APPLY, bank));
		day1.add(loanRepository.getLoanReportByStatusDateAndBank(startDate, endDate, Constant.INPROGRESS, bank));
		day1.add(loanRepository.getLoanReportByStatusDateAndBankReject(startDate, endDate, LoanStatus.REJECT.toString(), bank.getId()));
		day1.add(loanRepository.getLoanReportByStatusDateAndBank(startDate, endDate, Constant.DISBURS, bank));
		return day1;
	}

	private ResultVO gettingWeeklyReportLender() {

		ResultVO resultVO = new ResultVO();
		LocalDate startDate = LocalDate.now().minusDays(6);
		LocalDate lastData = LocalDate.now();
		Integer day = 1;

		List<Object> days = new ArrayList<>();
		while (day <= 7) {

			Map<String, List<Object>> mon = new HashMap<>();
			List<Object> data = new ArrayList<>();
			data.add(startDate.getDayOfWeek().toString().substring(0, 3));
			data.addAll(extractedByLender(startDate.atTime(LocalTime.MIN), startDate.atTime(LocalTime.MAX)));

			days.add(data);

			startDate = startDate.plusDays(1);
			day++;

		}
		resultVO.setDays(days);
		return resultVO;
	}

	private ResultVO gettingMonthlyReportLender() {
		ResultVO resultVO = new ResultVO();

		LocalDate startDate = LocalDate.now().minusWeeks(5).with(DayOfWeek.SUNDAY);
		LocalDate lastData = LocalDate.now();
		Integer week = 1;

		List<Object> weeks = new ArrayList<>();
		while (week <= 5) {
			LocalDate endDate = startDate.plusWeeks(1).minusDays(1);

			Map<String, List<Object>> mon = new HashMap<>();
			List<Object> data = new ArrayList<>();
			data.add(startDate.getDayOfMonth() + "/" + startDate.getMonthValue() + " - " + endDate.getDayOfMonth() + "/"
					+ endDate.getMonthValue());
			data.addAll(extractedByLender(startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX)));
			weeks.add(data);

			startDate = startDate.plusWeeks(1);
			if (startDate.isAfter(lastData)) {
				startDate = lastData;
			}
			week++;

		}
		resultVO.setWeeks(weeks);
		return resultVO;

	}

	@Override
	public ResultVO gettingYearlyReportLender() {

		ResultVO resultVO = new ResultVO();

		LocalDate startDate = LocalDate.now().minusMonths(5).withDayOfMonth(1);
		LocalDate lastData = LocalDate.now();
		Integer month = startDate.getMonthValue();
		List<Object> months = new ArrayList<>();
		do {

			month = startDate.getMonthValue();
			LocalDate endDate = startDate.plusDays(startDate.lengthOfMonth() - 1);

			Map<String, List<Object>> mon = new HashMap<>();
			List<Object> data = new ArrayList<>();
			data.add(startDate.getMonth().toString().substring(0, 3));
			data.addAll(extractedByLender(startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX)));

			months.add(data);

			startDate = startDate.plusMonths(1);
			if (startDate.isAfter(lastData)) {
				startDate = lastData;
			}

		} while (month != lastData.getMonthValue());
		resultVO.setMonths(months);
		return resultVO;
	}

	@Override
	public ReportVO getReportFromAuth(ReportType preReportType) {
		String role = userService.getRoleFromAuth();
		switch (role) {
		case "EXECUTIVE":
			 return loanReportByDaysExecutive(preReportType);
		case "LENDER":
			return loanReportByDaysLender(preReportType);
		case "FINAYO":
			return loanReportByDays(preReportType);
		case "ADMIN":
			return loanReportByDaysAdmin(preReportType);//need to implement
		default:
			return null;
		}
	}
	
	private List<Object> extractedByAdmin(LocalDateTime startDate, LocalDateTime endDate) {
		List<Object> day1 = new ArrayList<Object>();
		UserEntity user = userService.getUser();
		DSAEntity company = user.getCompany();
		day1.add(loanRepository.getLoanReportByStatusDateAndAdmin(startDate, endDate, LoanStatus.NEW.toString(), company.getId()));
		day1.add(loanRepository.getLoanReportByStatusDateAndAdmin(startDate, endDate, LoanStatus.APPLY.toString(), company.getId()));
		day1.add(loanRepository.getLoanReportByStatusDateAndAdmin(startDate, endDate, LoanStatus.INPROGRESS.toString(), company.getId()));
		day1.add(loanRepository.getLoanReportByStatusDateAndAdmin(startDate, endDate, LoanStatus.REJECT.toString(), company.getId()));
		day1.add(loanRepository.getLoanReportByStatusDateAndAdmin(startDate, endDate, LoanStatus.DISBURS.toString(), company.getId()));
		return day1;
	}

	private ResultVO gettingWeeklyReportAdmin() {

		ResultVO resultVO = new ResultVO();
		LocalDate startDate = LocalDate.now().minusDays(6);
		LocalDate lastData = LocalDate.now();
		Integer day = 1;

		List<Object> days = new ArrayList<>();
		while (day <= 7) {

			Map<String, List<Object>> mon = new HashMap<>();
			List<Object> data = new ArrayList<>();
			data.add(startDate.getDayOfWeek().toString().substring(0, 3));
			data.addAll(extractedByAdmin(startDate.atTime(LocalTime.MIN), startDate.atTime(LocalTime.MAX)));

			days.add(data);

			startDate = startDate.plusDays(1);
			day++;

		}
		resultVO.setDays(days);
		return resultVO;
	}

	private ResultVO gettingMonthlyReportAdmin() {
		ResultVO resultVO = new ResultVO();

		LocalDate startDate = LocalDate.now().minusWeeks(5).with(DayOfWeek.SUNDAY);
		LocalDate lastData = LocalDate.now();
		Integer week = 1;

		List<Object> weeks = new ArrayList<>();
		while (week <= 5) {
			LocalDate endDate = startDate.plusWeeks(1).minusDays(1);

			Map<String, List<Object>> mon = new HashMap<>();
			List<Object> data = new ArrayList<>();
			data.add(startDate.getDayOfMonth() + "/" + startDate.getMonthValue() + " - " + endDate.getDayOfMonth() + "/"
					+ endDate.getMonthValue());
			data.addAll(extractedByAdmin(startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX)));
			weeks.add(data);

			startDate = startDate.plusWeeks(1);
			if (startDate.isAfter(lastData)) {
				startDate = lastData;
			}
			week++;

		}
		resultVO.setWeeks(weeks);
		return resultVO;

	}

	private ResultVO gettingYearlyReportAdmin() {

		ResultVO resultVO = new ResultVO();

		LocalDate startDate = LocalDate.now().minusMonths(5).withDayOfMonth(1);
		LocalDate lastData = LocalDate.now();
		Integer month = startDate.getMonthValue();
		List<Object> months = new ArrayList<>();
		do {

			month = startDate.getMonthValue();
			LocalDate endDate = startDate.plusDays(startDate.lengthOfMonth() - 1);

			Map<String, List<Object>> mon = new HashMap<>();
			List<Object> data = new ArrayList<>();
			data.add(startDate.getMonth().toString().substring(0, 3));
			data.addAll(extractedByAdmin(startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX)));

			months.add(data);

			startDate = startDate.plusMonths(1);
			if (startDate.isAfter(lastData)) {
				startDate = lastData;
			}

		} while (month != lastData.getMonthValue());
		resultVO.setMonths(months);
		return resultVO;
	}
	
	private ReportVO loanReportByDaysAdmin(ReportType pReportType) {
		ReportVO reportVO = new ReportVO();
		if (pReportType.equals(ReportType.DAILY)) {
			reportVO.setError(""); // TODO: Need to implemeted
			reportVO.setType(ReportType.DAILY.toString());
			ResultVO resultVO = gettingWeeklyReportAdmin();
			reportVO.setResultVO(resultVO);
		}
		if (pReportType.equals(ReportType.WEEKLY)) {
			reportVO.setError(""); // TODO: Need to implemeted
			reportVO.setType(ReportType.WEEKLY.toString());
			ResultVO resultVO = gettingMonthlyReportAdmin();
			reportVO.setResultVO(resultVO);
		}
		if (pReportType.equals(ReportType.MONTHLY)) {
			reportVO.setError(""); // TODO: Need to implemeted
			reportVO.setType(ReportType.MONTHLY.toString());
			ResultVO resultVO = gettingYearlyReportAdmin();
			reportVO.setResultVO(resultVO);
		}

		return reportVO;
	}


}
