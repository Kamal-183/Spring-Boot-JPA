package com.kilpi.finayo.Service.Impl;

import com.kilpi.finayo.Constant.Constant;
import com.kilpi.finayo.Constant.LoanStatus;
import com.kilpi.finayo.Domain.*;
import com.kilpi.finayo.Repository.*;
import com.kilpi.finayo.Service.ExecutiveService;
import com.kilpi.finayo.Service.UserService;
import com.kilpi.finayo.VO.LoanStatsVO;
import com.kilpi.finayo.VO.LoanVO;
import com.kilpi.finayo.exception.FinayoGenericException;
import com.kilpi.finayo.exception.NotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ExecutiveServiceImpl implements ExecutiveService {

    @Autowired
    private LoanRepository loanRepository;

    @Autowired
    BankRepository bankRepository;

    @Autowired
    UserService userService;

    @Override
    public List<LoanVO> getLoans() {
        ExecutiveEntity executive = userService.getExecutive();
        List<Loan> loans = loanRepository.findByExecutiveId(executive.getId());
        return loans.stream().map(Loan::toVo).collect(Collectors.toList()) ;
    }

    @Override
    public LoanVO updateLoan(Long loanId, String bCode) {
        ExecutiveEntity executive = userService.getExecutive();
        Optional<Loan> isLoan = loanRepository.findById(loanId);
        Optional<BankEntity> isBank = bankRepository.findByCode(bCode);
        if(!isBank.isPresent()){
            throw new NotFoundException("Invalid Bank");
        }
        if(isLoan.isPresent()){
            Loan loan = isLoan.get();
            if(executive.getId() != loan.getProfile().getExecutiveId()){
                throw new NotFoundException("Invalid Loan for executive");
            }
            loan.setBank(isBank.get());
            loan.setLoanStatus(LoanStatus.APPLY);

            for (BankLoanEntity bankLoan : loan.getBanks() ) {
                if(isBank.get().getId() == bankLoan.getBank().getId())
                    bankLoan.setStatus(LoanStatus.APPLY.toString());
            }

            return loanRepository.save(loan).toVo();
        } else {
            throw new NotFoundException("Invalid Loan");
        }
    }

    @Override
    public LoanStatsVO getExecutiveStastistitics() {
        LoanStatsVO loanStatsVO = null;
        loanStatsVO = new LoanStatsVO();

        ExecutiveEntity executive = userService.getExecutive();

        List<Loan> loans = loanRepository.findByExecutiveId(executive.getId());

        Long total = (long) loans.size();
        Long disburse = 0L, pending = 0L, reject = 0L, inProgress = 0L, approve = 0L, apply = 0L, newL = 0L;

        for (Loan loan: loans) {
            if (loan.getLoanStatus().equals(LoanStatus.DISBURS)) {
                disburse++;
            } else if (loan.getLoanStatus().equals(LoanStatus.HOLD)) {
                pending++;
            } else if (loan.getLoanStatus().equals(LoanStatus.REJECT)) {
                reject++;
            } else if (loan.getLoanStatus().equals(LoanStatus.INPROGRESS)) {
                inProgress++;
            } else if (loan.getLoanStatus().equals(LoanStatus.APPROVE)) {
                approve++;
            } else if (loan.getLoanStatus().equals(LoanStatus.APPLY)) {
                apply++;
            } else if (loan.getLoanStatus().equals(LoanStatus.NEW)) {
                newL++;
            }
        }

        loanStatsVO.setTotal( total == null ? 0 : total);
        loanStatsVO.setDisburse( disburse == null ? 0 : disburse);
        loanStatsVO.setPending( pending == null ? 0 : pending);
        loanStatsVO.setReject(reject == null ? 0 : reject);
        loanStatsVO.setApply(apply == null ? 0 : apply);
        loanStatsVO.setApprove(approve == null ? 0 : approve);
        loanStatsVO.setNewLoan(newL == null ? 0 : newL);
        loanStatsVO.setInProgress(inProgress == null ? 0 : inProgress);
        return loanStatsVO;
    }


}
