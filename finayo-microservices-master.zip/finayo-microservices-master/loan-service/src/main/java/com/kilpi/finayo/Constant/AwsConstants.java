package com.kilpi.finayo.Constant;

public final class AwsConstants {
	
	public static final String ACCESS_KEY="AKIAU4W7N7V4TWM3ORLQ";
	public static final String SECRET_KEY="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";
}
