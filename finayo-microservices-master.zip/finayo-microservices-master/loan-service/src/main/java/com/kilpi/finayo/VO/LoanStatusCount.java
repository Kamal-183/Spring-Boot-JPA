package com.kilpi.finayo.VO;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LoanStatusCount {
	
	@JsonProperty("apply")
	public Long apply;
	@JsonProperty("inprogress")
	public Long inprogress;
	@JsonProperty("hold")
	public Long hold;
	@JsonProperty("reject")
	public Long reject;
	@JsonProperty("approve")
	public Long approve;
	@JsonProperty("disburse")
	public Long disburse;

}
