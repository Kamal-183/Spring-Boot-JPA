package com.kilpi.finayo.Repository;

import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.kilpi.finayo.Constant.LoanStatus;
import com.kilpi.finayo.Domain.BankEntity;
import com.kilpi.finayo.Domain.ExecutiveEntity;
import com.kilpi.finayo.Domain.Loan;
import com.kilpi.finayo.Domain.Profile;

@Repository("loanRepository")
public interface LoanRepository extends JpaRepository<Loan, Long> {
	
	Loan findByProfile(Profile profile);
	
	
	@Query(value = "SELECT sum(loanAmount) FROM Loan")
    public Long sumTotalLoan();

	@Query(value = "SELECT sum(loanAmount) FROM Loan WHERE bank = ?1")
	public Long sumTotalLoanByBank(BankEntity bank);

	@Query(value = "SELECT sum(l.loanAmount) FROM Loan as l where l.LoanStatus in (:status) AND l.bank = (:bank)")
	public Long getSummaryByStatusAndBank(@Param("status")List<LoanStatus> statusList, @Param("bank")BankEntity bank);
	
	 @Query(value = "SELECT sum(l.loanAmount) FROM Loan as l where l.LoanStatus in (:status)")
	 public Long getSummaryByStatus(@Param("status")List<LoanStatus> statusList);

	
	 @Query(value = "SELECT count(*) FROM Loan as l where l.LoanStatus in (:status)")
	 public Long totalCountByStatus(@Param("status")List<LoanStatus> statusList);
	
	@Query(value = "SELECT count(*) FROM Loan as l where l.LoanStatus in (:status) and l.updatedby BETWEEN :startDate AND :endDate")
    public Long getLoanReportByStatusDate(@Param("startDate") LocalDateTime startDate,@Param("endDate") LocalDateTime endDate,@Param("status")List<LoanStatus> statusList);

	@Query(value = "SELECT count(*) FROM Loan as l where l.LoanStatus in (:status) and l.updatedby BETWEEN :startDate AND :endDate AND l.profile.executiveId = (:executiveId)")
    public Long getLoanReportByStatusDateAndExecutive(@Param("startDate") LocalDateTime startDate,@Param("endDate") LocalDateTime endDate,@Param("status")List<LoanStatus> statusList,@Param("executiveId")Integer executiveId);

	@Query(value = "SELECT count(*) FROM Loan as l where l.LoanStatus in (:status) and l.updatedby BETWEEN :startDate AND :endDate AND l.bank = (:bank)")
	public Long getLoanReportByStatusDateAndBank(@Param("startDate") LocalDateTime startDate,@Param("endDate") LocalDateTime endDate,@Param("status")List<LoanStatus> statusList, @Param("bank")BankEntity bank);

	@Query(value="select  distinct  count(loan_details.lid)"
			+ "from loan_details "
			+ "LEFT JOIN bank_entity_loan ON loan_details.lid =bank_entity_loan.loan_lid "
			+ "where bank_entity_loan.status = :status and loan_details.updatedby BETWEEN :startDate AND :endDate "
			+ "AND bank_entity_loan.bank_entity_id=:id", nativeQuery=true)
	public Long getLoanReportByStatusDateAndBankReject(@Param("startDate") LocalDateTime startDate,@Param("endDate") LocalDateTime endDate,@Param("status")String statusList, @Param("id")Integer id);


	@Query(value="select  distinct  count(loan_details.lid),branch.first_name \r\n"
			+ "from profile_details \r\n"
			+ "JOIN loan_details ON loan_details.profile_id =profile_details.pid\r\n"
			+ "join executive  on profile_details.executive_id = executive.id \r\n"
			+ "join branch  on branch.id = executive.branch_id\r\n"
			+ "where loan_details.status = :status GROUP BY branch.first_name", nativeQuery=true)
    public List<Object[]> getStatusByBranch(@Param("status") String status);
    
	@Query(value="select  distinct  count(loan_details.lid),branch.first_name \r\n"
			+ "from profile_details \r\n"
			+ "JOIN loan_details ON loan_details.profile_id =profile_details.pid\r\n"
			+ "join executive  on profile_details.executive_id = executive.id \r\n"
			+ "join branch on branch.id = executive.branch_id\r\n"
			+ "where loan_details.status = :status and loan_details.updatedby BETWEEN :startDate AND :endDate"
			+ " GROUP BY branch.first_name", nativeQuery=true)
    public List<Object[]> getDailyStatusByBranch(@Param("status") String status ,
    		@Param("startDate") LocalDateTime startDate,@Param("endDate") LocalDateTime endDate);
    
    
	@Query(value="select SUM(CASE WHEN loan_details.status='APPLY' THEN 1 ELSE 0 END) as applied,\r\n"
			+ "SUM(CASE WHEN loan_details.status='HOLD' THEN 1 ELSE 0 END) as hold,\r\n"
			+ "SUM(CASE WHEN loan_details.status='REJECT' THEN 1 ELSE 0 END) as rejected,\r\n"
			+ "SUM(CASE WHEN loan_details.status='DISBURSE' THEN 1 ELSE 0 END) as disbursh\r\n "
			+ "from profile_details JOIN loan_details ON loan_details.profile_id =profile_details.pid\r\n"
			+ "join executive  on profile_details.executive_id = executive.id", nativeQuery=true)
    public List<Object[]> getCountAllExecutive();

	@Query(value="select SUM(CASE WHEN loan_details.status='APPLY' THEN 1 ELSE 0 END) as applied,\r\n"
			+ "SUM(CASE WHEN loan_details.status='HOLD' THEN 1 ELSE 0 END) as hold,\r\n"
			+ "SUM(CASE WHEN loan_details.status='REJECT' THEN 1 ELSE 0 END) as rejected,\r\n"
			+ "SUM(CASE WHEN loan_details.status='DISBURSE' THEN 1 ELSE 0 END) as disbursh\r\n "
			+ "from loan_details where bank_id=?1", nativeQuery=true)
	public List<Object[]> getCountAllByBank(Integer id);
    
	@Query(value="select SUM(CASE WHEN loan_details.status='APPLY' THEN 1 ELSE 0 END) as applied,\r\n"
			+ "SUM(CASE WHEN loan_details.status='HOLD' THEN 1 ELSE 0 END) as hold,\r\n"
			+ "SUM(CASE WHEN loan_details.status='REJECT' THEN 1 ELSE 0 END) as rejected,\r\n"
			+ "SUM(CASE WHEN loan_details.status='DISBURSE' THEN 1 ELSE 0 END) as disbursh\r\n"
			+ "from profile_details JOIN loan_details ON loan_details.profile_id =profile_details.pid\r\n"
			+ "join executive  on profile_details.executive_id = executive.id \r\n"
			+ "where executive.first_name= :name GROUP BY executive.first_name", nativeQuery=true)
    public List<Object[]> getCountByExecutiveName(@Param("name")String name);
    
	@Query(value="select  distinct  count(profile_details.pid)\r\n"
			+ "from profile_details \r\n"
			+ "JOIN loan_details ON loan_details.profile_id =profile_details.pid\r\n"
			+ "join executive  on profile_details.executive_id = executive.id \r\n"
			+ "join branch  on branch.id = executive.branch_id\r\n"
			+ "where loan_details.status in (:status) and branch.first_name=:name ", nativeQuery=true)
    public List<Object[]> getCountByBranch(@Param("name")String name,@Param("status") List<String> status);
    
	@Query(value="select SUM(CASE WHEN loan_details.status='APPLY' THEN 1 ELSE 0 END) as applied,\r\n"
			+ "SUM(CASE WHEN loan_details.status='HOLD' THEN 1 ELSE 0 END) as hold,\r\n"
			+ "SUM(CASE WHEN loan_details.status='REJECT' THEN 1 ELSE 0 END) as rejected,\r\n"
			+ "SUM(CASE WHEN loan_details.status='DISBURSE' THEN 1 ELSE 0 END) as disbursh\r\n"
			+ "from profile_details JOIN loan_details ON loan_details.profile_id =profile_details.pid\r\n"
			+ "join executive  on profile_details.executive_id = executive.id \r\n"
			+ "where executive.id= :id GROUP BY executive.id", nativeQuery=true)
    public List<Object[]> getCountByExecutiveId(@Param("id")Integer id);
    
	@Query(value="select  distinct  count(profile_details.pid)\r\n"
			+ "from profile_details \r\n"
			+ "JOIN loan_details ON loan_details.profile_id =profile_details.pid\r\n"
			+ "join executive  on profile_details.executive_id = executive.id \r\n"
			+ "join branch  on branch.id = executive.branch_id\r\n"
			+ "where loan_details.status in (:status) and branch.id=:id ", nativeQuery=true)
    public List<Object[]> getCountByBranchId(@Param("id")Integer name,@Param("status") List<String> status);
    
	@Query(value="select SUM(CASE WHEN loan_details.status='APPLY' THEN 1 ELSE 0 END) as applied,\r\n"
			+ "SUM(CASE WHEN loan_details.status='HOLD' THEN 1 ELSE 0 END) as hold,\r\n"
			+ "SUM(CASE WHEN loan_details.status='REJECT' THEN 1 ELSE 0 END) as rejected,\r\n"
			+ "SUM(CASE WHEN loan_details.status='DISBURSE' THEN 1 ELSE 0 END) as disbursh,\r\n"
			+ "SUM(CASE WHEN loan_details.status='APPROVE' THEN 1 ELSE 0 END) as approve,\r\n"
			+ "SUM(CASE WHEN loan_details.status='INPROGRESS' THEN 1 ELSE 0 END) as inprogress\r\n"
			+ "from profile_details JOIN loan_details ON loan_details.profile_id =profile_details.pid\r\n"
			+ "where profile_details.executive_id= :id and loan_details.updatedby BETWEEN :startDate AND :endDate", nativeQuery=true)
    public List<Object[]> getCountByExecutiveDate(@Param("id")Integer id,
    		@Param("startDate") LocalDateTime startDate,@Param("endDate") LocalDateTime endDate);
    
	@Query(value="select SUM(CASE WHEN loan_details.status='APPLY' THEN 1 ELSE 0 END) as applied,\r\n"
			+ "SUM(CASE WHEN loan_details.status='HOLD' THEN 1 ELSE 0 END) as hold,\r\n"
			+ "SUM(CASE WHEN loan_details.status='REJECT' THEN 1 ELSE 0 END) as rejected,\r\n"
			+ "SUM(CASE WHEN loan_details.status='DISBURSE' THEN 1 ELSE 0 END) as disbursh\r\n"
			+ "from loan_details where loan_details.updatedby BETWEEN :startDate AND :endDate", nativeQuery=true)
    public List<Object[]> getCountByDate(@Param("startDate") LocalDateTime startDate,@Param("endDate") LocalDateTime endDate);

    @Query(value="select SUM(CASE WHEN loan_details.status='APPLY' THEN 1 ELSE 0 END) as applied,\r\n"
			+ "SUM(CASE WHEN loan_details.status='HOLD' THEN 1 ELSE 0 END) as hold,\r\n"
			+ "SUM(CASE WHEN loan_details.status='REJECT' THEN 1 ELSE 0 END) as rejected,\r\n"
			+ "SUM(CASE WHEN loan_details.status='DISBURSE' THEN 1 ELSE 0 END) as disbursh,\r\n"
			+ "SUM(CASE WHEN loan_details.status='APPROVE' THEN 1 ELSE 0 END) as approve,\r\n"
			+ "SUM(CASE WHEN loan_details.status='INPROGRESS' THEN 1 ELSE 0 END) as inprogress\r\n"
			+ "from profile_details JOIN loan_details ON loan_details.profile_id =profile_details.pid\r\n"
			+ "join executive on profile_details.executive_id = executive.id \r\n"
			+ "where executive.branch_id= :id and loan_details.updatedby BETWEEN :startDate AND :endDate", nativeQuery=true)
    public List<Object[]> getCountByBranchDate(@Param("id")Integer id,
    		@Param("startDate") LocalDateTime startDate,@Param("endDate") LocalDateTime endDate);
	

	List<Loan> findByBank(BankEntity bankEntity);


	@Query("SELECT l FROM Loan l WHERE l.bank.id = ?1")
	List<Loan> findByBankId(Integer id);


	@Query("SELECT l FROM Loan l WHERE l.profile.executiveId = ?1")
    List<Loan> findByExecutiveId(Integer id);

	@Query("SELECT l FROM Loan l WHERE l.LoanStatus = ?1")
	List<Loan> findByStatus(LoanStatus status);

	@Query("SELECT l FROM Loan l WHERE l.profile.executiveId = ?1 AND l.LoanStatus = ?2")
	List<Loan> findByExecutiveIdAndStatus(Integer id, LoanStatus loanStatus);
	
	//Admin Query
	@Query(value="select  distinct  count(loan_details.lid)"
			+ "from profile_details "
			+ "LEFT JOIN loan_details ON loan_details.profile_id =profile_details.pid "
			+ "LEFT JOIN executive  on profile_details.executive_id = executive.id "
			+ "LEFT JOIN branch on branch.id = executive.branch_id "
			+ "LEFT JOIN dsa on branch.business_type_id = dsa.id "
			+ "where loan_details.status = :status and loan_details.updatedby BETWEEN :startDate AND :endDate "
			+ "AND dsa.id=:id", nativeQuery=true)
    public Long getLoanReportByStatusDateAndAdmin(@Param("startDate") LocalDateTime startDate,@Param("endDate") LocalDateTime endDate,@Param("status") String statusList,@Param("id")Integer id);

	@Query("SELECT l FROM Loan l WHERE l.bank = ?1 AND l.LoanStatus = ?2")
	List<Loan> findByBankAndStatus(BankEntity exe, LoanStatus status);

	@Query("SELECT l FROM Loan l WHERE l.LoanStatus = ?1")
	List<Loan> findByBankAndStatusNEW(LoanStatus loanStatus);

	@Query(value = "SELECT count(*) FROM Loan as l where l.LoanStatus in (:status) and l.updatedby BETWEEN :startDate AND :endDate")
	Long getLoanReportByStatusDateNew(LocalDateTime startDate, LocalDateTime endDate, List<LoanStatus> status);
}
