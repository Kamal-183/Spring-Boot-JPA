package com.kilpi.finayo.Service;

import com.kilpi.finayo.Domain.BankEntity;
import com.kilpi.finayo.Domain.ExecutiveEntity;
import com.kilpi.finayo.Domain.UserEntity;

public interface UserService {
   
	ExecutiveEntity getExecutive();
   
    BankEntity getBankDetails();
    
    String getRoleFromAuth();
    
    public UserEntity getUser();
}
