package com.kilpi.finayo.Domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.kilpi.finayo.VO.ProfileVO;

import lombok.Data;

import java.sql.Blob;

@Data
@Entity
@Table(name = "profile_details")
public class Profile {

	@Id
	@Column(name = "pid")
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Long id;

	@Column(name = "name")
	private String name;

	@Column(name = "dob")
	private String dob;

	@Column(name = "gender")
	private String gender;

	@NotNull(message = "EMAIL is mandatory")
	private String email;

	@Column(name = "phone_no")
	private String phoneNo;

	@Column(name = "address")
	private String officeAddress;

	@Column(name = "city")
	private String city;

	@Column(name = "state")
	private String state;

	@Column(name = "country")
	private String country;

	@Column(name = "postal")
	private String postal;

	@Column(name = "organisation_name")
	private String orgName;

	@Column(name = "organisation_type")
	private String orgType;

	@Column(name = "cibil")
	private Double cibil;

	@Column(name = "pan_no")
	private String panNo;

	@Column(name = "aadhar")
	private String aadhar;

	@Column(name = "dl")
	private String dl;

	@Column(name = "avatar", length = 4000)
	private String avatar;

	@Column(name = "executive_id")
	private Integer executiveId;
	
	public ProfileVO toVo() {
        return ProfileVO.builder()
                .profileId(id)
                .name(name)
				.dob(dob)
                .email(email)
                .phoneNo(phoneNo)
                .officeAddress(officeAddress)
                .city(city)
                .country(country)
				.state(state)
                .postal(postal)
                .orgName(orgName)
                .orgType(orgType)
                .cibil(cibil)
                .panNo(panNo)
				.dl(dl)
				.aadhar(aadhar)
				.avatar(avatar)
				.executiveId(executiveId)
				.build();
	}
	

	
}
