package com.kilpi.finayo.Mapper;

import com.kilpi.finayo.Constant.LoanStatus;
import org.springframework.stereotype.Service;

import com.kilpi.finayo.Domain.Loan;
import com.kilpi.finayo.Domain.Profile;
import com.kilpi.finayo.VO.LoanVO;
import com.kilpi.finayo.VO.ProfileVO;

@Service
public class DtoConverter {

	public Profile profileVotoEntity(ProfileVO pProfileVO) {
		Profile profile = new Profile();
		profile.setName(pProfileVO.getName());
		profile.setDob(pProfileVO.getDob());
		profile.setEmail(pProfileVO.getEmail());
		profile.setPhoneNo(pProfileVO.getPhoneNo());
		profile.setOfficeAddress(pProfileVO.getOfficeAddress());
		profile.setCity(pProfileVO.getCity());
		profile.setCountry(pProfileVO.getCountry());
		profile.setState(pProfileVO.getState());
		profile.setPostal(pProfileVO.getPostal());
		profile.setOrgName(pProfileVO.getOrgName());
		profile.setOrgType(pProfileVO.getOrgType());
		profile.setCibil(pProfileVO.getCibil());
		profile.setPanNo(pProfileVO.getPanNo());
		profile.setAadhar(pProfileVO.getAadhar());
		profile.setDl(pProfileVO.getDl());
		profile.setAvatar(pProfileVO.getAvatar());
		profile.setExecutiveId(pProfileVO.getExecutiveId());
		return profile;
	}

	public Loan loanVotoEntity(LoanVO pLoanVO) {
		Loan loan = new Loan();
		loan.setLoanAmount(pLoanVO.getLoanAmount());
		loan.setDownPayment(pLoanVO.getDownPayment());
		loan.setTenure(pLoanVO.getTenure());
		loan.setInterestRate(pLoanVO.getInterestRate());
		loan.setVehicleAmount(pLoanVO.getVehicleAmount());
		loan.setStmntPath(pLoanVO.getStmntPath());
		loan.setRecptPath(pLoanVO.getRecptPath());
		loan.setLoanStatus(LoanStatus.NEW);
		loan.setProfile(profileVotoEntity(pLoanVO.getProfileVO()));
		return loan;
	}

}
