package com.kilpi.finayo.VO;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Blob;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProfileVO {
	private Long profileId;

	@NotNull
    @Size(min = 3, max = 25, message = "name must be of min 3 length")
	private String name;

	@NotNull
	@Size(min = 3, max = 25, message = "name must be of min 3 length")
	private String dob;

	@Email
	private String email;
	@NotNull
	@Pattern(regexp = "^([1-9]){9}[0-9]$",message = "Invalid Mobile No.")
	private String phoneNo;

	@NotNull
	@Size(min = 5, max = 250, message = "office address must be of min 5")
	private String officeAddress;

	@NotNull
	@Size(min = 3, max = 25, message = "city must be of min 3 length")
	private String city;

	@NotNull
	@Size(min = 3, max = 25, message = "name must be of min 3 length")
	private String state;

	@NotNull
    @Size(min = 3, max = 25, message = "name must be of min 3 length")
	private String country;

	@NotNull
    @Size(max=5)
	private String postal;

	@NotNull
    @Size(min = 3, max = 25, message = "address must be of min 3")
	private String orgName;

	@NotNull
    @Size(min = 3, max = 25, message = "org type must be of min 3")
	private String orgType;

	@NotNull
	private Double cibil;

	@NotNull
	@Pattern(regexp = "^[A-Z]{5}[0-9]{4}[A-Z]{1}$",message = "invalid PAN")
	private String panNo;

	@Size(min = 3, max = 25, message = "invalid DL")
	private String dl;

	@NotNull
	@Size(min = 12, max = 12, message = "invalid Aadhar")
	private String aadhar;

	private String avatar;

	private Integer executiveId;

	private LoanVO loanVO;

}
