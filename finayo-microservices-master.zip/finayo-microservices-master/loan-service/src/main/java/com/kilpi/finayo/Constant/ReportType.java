package com.kilpi.finayo.Constant;

public enum ReportType {
	DAILY, WEEKLY, MONTHLY
}