package com.kilpi.finayo.VO;

import java.time.LocalDateTime;
import java.util.List;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.kilpi.finayo.Constant.LoanStatus;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
public class LoanVO {
	
	private Long loanId;
	@NotNull(message = "loan amount should not be null")
	private Double loanAmount;
	@NotNull(message = "downpayment amount should not be null")
	private Double downPayment;
	@NotNull(message = "tenure should not be null")
	private Integer tenure;
	@NotNull(message = "interest should not be null")
	private Double interestRate;
	@NotNull
	private Double vehicleAmount;
	private LocalDateTime appDate;
	private LocalDateTime completeDate;
	@NotEmpty(message = "path should not empty")
	private String stmntPath;
	@NotEmpty(message = "path should not empty")
	private String recptPath;
	private LoanStatus loanStatus;
	private ProfileVO profileVO;
	private List<BankVO> bankVO;
	private BankVO lender;
}

