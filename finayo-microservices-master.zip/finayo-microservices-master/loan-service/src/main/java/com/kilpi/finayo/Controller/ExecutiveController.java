package com.kilpi.finayo.Controller;


import com.kilpi.finayo.Service.ExecutiveService;
import com.kilpi.finayo.Service.UserService;
import com.kilpi.finayo.VO.ResponseVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "executive")
public class ExecutiveController {

    @Autowired
    private ExecutiveService executiveService;
    
    @Autowired
    private UserService userService;

    @GetMapping(value = "/loans/approved")
    public ResponseVO loans() {
        return ResponseVO.builder()
                .data(executiveService.getLoans())
                .status(200)
                .message("Executive Loan List")
                .build();
    }

    @PutMapping(value = "/loans/apply/{loanId}/{bCode}")
    public ResponseVO apply(@PathVariable Long loanId, @PathVariable String bCode) {
        return ResponseVO.builder()
                .data(executiveService.updateLoan(loanId, bCode))
                .status(200)
                .message("Loan Application sent to bank")
                .build();
    }

    @GetMapping(value = "/stats/pie")
    public ResponseVO getStats() {
        return ResponseVO.builder()
                .data(executiveService.getExecutiveStastistitics())
                .status(200)
                .message("Loan List")
                .build();
    }
        


}
